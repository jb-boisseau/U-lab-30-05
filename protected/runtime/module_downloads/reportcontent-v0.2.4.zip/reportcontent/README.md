## Description

This module allows users to report posts for various reasons to space and super admins. It will help to reduce spam inside the network.

__Author:__ Marjana Pesic  