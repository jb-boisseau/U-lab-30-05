<?php
return array (
  'Here you can manage reported posts for this space.' => 'Vous pouvez gérer ici les contenus signalés dans cet espace.',
);
