<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirmer</strong> la suppression de cette publication',
  '<strong>Confirm</strong> report deletion' => '<strong>Confirmer</strong> le signalement de cette publication',
  'Approve' => 'Approuver',
  'Approve post' => 'Approuver la publication',
  'Cancel' => 'Annuler',
  'Content' => 'Contenu',
  'Delete' => 'Supprimer',
  'Delete post' => 'Supprimer la publication',
  'Do you really want to approve this post?' => 'Voulez-vous vraiment approuver cette publication ?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Voulez-vous vraiment supprimer cette publication ? Tous les "j\'aime" et les commentaires seront définitivement perdus !',
  'Reason' => 'Raison',
  'Reporter' => 'Signaler',
  'There are no reported posts.' => 'Il n\'y a aucune publication signalée.',
);
