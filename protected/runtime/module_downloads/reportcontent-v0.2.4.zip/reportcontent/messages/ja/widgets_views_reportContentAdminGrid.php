<?php
return array (
  '<strong>Confirm</strong> post deletion' => '',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'キャンセル',
  'Content' => 'コンテンツ',
  'Delete' => '削除',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => '',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
