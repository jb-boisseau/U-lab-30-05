<?php
return array (
  'Here you can manage reported posts for this space.' => 'Her kan du administrere anmeldte opslag for denne side.',
);
