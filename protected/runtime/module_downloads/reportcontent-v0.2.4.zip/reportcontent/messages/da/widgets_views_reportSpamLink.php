<?php
return array (
  'Does not belong here' => 'Hører ikke til på denne side',
  'Help Us Understand What\'s Happening' => 'Hjælp os med at forstå hvad der sker',
  'It\'s offensive' => 'Det er irriterende eller uinteressant',
  'It\'s spam' => 'Det er spam',
  'Report post' => 'Anmeld opslag',
  'Submit' => 'Indsend',
);
