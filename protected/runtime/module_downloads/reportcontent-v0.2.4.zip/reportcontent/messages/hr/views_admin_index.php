<?php
return array (
  'Here you can manage reported users posts.' => 'Ovdje možete upravljati prijavljenim postovima korisnika.',
);
