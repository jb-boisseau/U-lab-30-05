<?php
return array (
  'Here you can manage reported posts for this space.' => 'Zde můžete spravovat hlášené příspěvky tohoto prostoru.',
);
