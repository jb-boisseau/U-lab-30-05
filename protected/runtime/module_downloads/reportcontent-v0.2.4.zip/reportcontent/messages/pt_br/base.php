<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Gerenciar <strong>posts reportados</strong>',
  'Please provide a reason, why you want to report this content.' => 'Por favor, forneça uma razão pela qual você deseja denunciar esse conteúdo.',
  'Reported posts' => 'Posts reportados',
  'Why do you want to report this post?' => 'Por que você quer denunciar essa postagem?',
  'by :displayName' => 'por :displayName',
  'created by :displayName' => 'criado por :displayName',
);
