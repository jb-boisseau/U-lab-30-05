<?php
return array (
  'Here you can manage reported users posts.' => 'Aqui você pode gerenciar posts de usuários reportados.',
);
