<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirme</strong> exclusão da postagem',
  '<strong>Confirm</strong> report deletion' => '<strong>Confirme</strong> exclusão da denúncia',
  'Approve' => 'Aprovar',
  'Approve post' => 'Aprovar postagem',
  'Cancel' => 'Cancelar',
  'Content' => 'Conteúdo',
  'Delete' => 'Excluir',
  'Delete post' => 'Excluir postagem',
  'Do you really want to approve this post?' => 'Você realmente quer aprovar esta postagem?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Você realmente quer excluir esta postagem? Todas as curtidas e comentários serão perdidos!',
  'Reason' => 'Motivo',
  'Reporter' => 'Relator',
  'There are no reported posts.' => 'Não há postagens denunciadas.',
);
