<?php
return array (
  'Here you can manage reported posts for this space.' => 'Hier kun je gerapporteerde posts beheren.',
);
