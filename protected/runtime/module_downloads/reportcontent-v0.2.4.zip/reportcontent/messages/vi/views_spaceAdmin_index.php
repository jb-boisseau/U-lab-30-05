<?php
return array (
  'Here you can manage reported posts for this space.' => 'Tại đây bạn có thể quản lý bài post bị tố cáo của phòng này.',
);
