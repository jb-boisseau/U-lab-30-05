<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Xác nhận</strong> xóa bài viết',
  '<strong>Confirm</strong> report deletion' => '<strong>Xác nhận</strong> xóa tố cáo',
  'Approve' => 'Duyệt',
  'Approve post' => 'Duyệt post',
  'Cancel' => 'Hủy',
  'Content' => 'Nội dung',
  'Delete' => 'Xóa',
  'Delete post' => 'Xóa post',
  'Do you really want to approve this post?' => 'Bạn thực sự muốn duyệt bài post này?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Bạn có chắc chắn muốn xóa bài viết này? Tất cả yêu thích và bình luận sẽ bị mất!',
  'Reason' => 'Lý do',
  'Reporter' => 'Người tố cáo',
  'There are no reported posts.' => 'Không có bài post nào bị tố cáo.',
);
