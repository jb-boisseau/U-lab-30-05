<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>تأكيد</strong> رغبتك في الحذف',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'إلغاء',
  'Content' => '',
  'Delete' => 'حذف',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'هل انت متأكد من رغبتك في حذف هذه المحتويات؟ جميع الردود و نقاط الإعجاب ستختفي!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
