<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Apstiprināt</strong> ieraksta dzēšanu',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Atcelt',
  'Content' => 'Saturs',
  'Delete' => 'Dzēst',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Vai tiešām vēlies dzēst šo ierakstu? Visi patīk un komentāri tiks dzēsti!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
