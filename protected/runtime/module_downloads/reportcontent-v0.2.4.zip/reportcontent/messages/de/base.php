<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Verwalte <strong>gemeldete Beiträge</strong>',
  'Please provide a reason, why you want to report this content.' => 'Bitte gib einen Grund an, warum du diesen Inhalt melden möchtest.',
  'Reported posts' => 'Gemeldete Beiträge',
  'Why do you want to report this post?' => 'Warum möchtest Du den Beitrag melden?',
  'by :displayName' => 'von :displayName',
  'created by :displayName' => 'erstellt von :displayName',
);
