<?php
return array (
  'Here you can manage reported posts for this space.' => 'Hier kannst du gemeldete Beiträge dieses Space\' verwalten.',
);
