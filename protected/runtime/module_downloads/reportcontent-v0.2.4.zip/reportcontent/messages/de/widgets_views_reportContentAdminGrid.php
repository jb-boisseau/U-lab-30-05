<?php
return array (
  '<strong>Confirm</strong> post deletion' => 'Löschen des Beitrages<strong>bestätigen</strong>',
  '<strong>Confirm</strong> report deletion' => 'Löschen der Meldung<strong>bestätigen</strong>',
  'Approve' => 'Genehmigen',
  'Approve post' => 'Beitrag genehmigen',
  'Cancel' => 'Abbrechen',
  'Content' => 'Inhalt',
  'Delete' => 'Löschen',
  'Delete post' => 'Beitrag löschen',
  'Do you really want to approve this post?' => 'Möchtest du diesen Beitrag wirklich genehmigen?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Möchtest du diesen Beitrag wirklich löschen? Alle "Gefällt mir" und Kommentare werden unwiederbringlich entfernt.',
  'Reason' => 'Grund',
  'Reporter' => 'Melder',
  'There are no reported posts.' => 'Keine gemeldeten Beiträge.',
);
