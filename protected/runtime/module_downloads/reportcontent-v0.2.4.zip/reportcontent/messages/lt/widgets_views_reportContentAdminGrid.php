<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Patvirtinti</strong> įrašo ištrynimą',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Atšaukti',
  'Content' => 'Turinys',
  'Delete' => 'Ištrinti',
  'Delete post' => 'Ištrinti skelbimą',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Ar tikrai norite ištrinti šį įrašą? Visi komentarai bus ištrinti!',
  'Reason' => 'Priežastis',
  'Reporter' => 'Pranešėjas',
  'There are no reported posts.' => '',
);
