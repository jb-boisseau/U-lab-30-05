<?php
return array (
  'An user has reported your post as offensive.' => 'Vartotojas pranešė, kad Jūsų skelbimas yra įžeidžiantis.',
  'An user has reported your post as spam.' => 'Vartotojas pranešė, kad Jūsų skelbimas yra šiukšlė.',
  'An user has reported your post for not belonging to the space.' => 'Vartotojas pranešė, kad Jūsų skelbimas nepriklauso erdvei.',
);
