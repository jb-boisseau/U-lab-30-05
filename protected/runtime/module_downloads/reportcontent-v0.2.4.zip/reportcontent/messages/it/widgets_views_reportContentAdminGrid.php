<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Conferma</strong> la cancellazione dell\'articolo',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Annulla',
  'Content' => 'Contenuti',
  'Delete' => 'Cancella',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Vuoi veramente cancellare quest\'articolo? Tutti i commenti e i like andranno persi!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
