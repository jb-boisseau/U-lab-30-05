Changelog
=========
0.2.4 -  (April 17, 2018)
----------------------
- Fix #21 Report notification not displayed
