<?php

namespace tests\codeception\unit\modules\reportcontent;

use tests\codeception\_support\HumHubDbTestCase;
use Codeception\Specify;

class ReportContentTest extends HumHubDbTestCase
{

    use Specify;
    
    public function testInit()
    {
        
      

    }
}
