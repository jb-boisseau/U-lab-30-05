<?php
return array (
  'Update download failed! (%error%)' => 'Falha no download da atualização! (%erro%)',
);
