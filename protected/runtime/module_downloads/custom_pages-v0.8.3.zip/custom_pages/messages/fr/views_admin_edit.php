<?php
return array (
  '<strong>Create</strong> page' => '<strong>Créer</strong> une page',
  '<strong>Edit</strong> page' => '<strong>Modifier</strong> une page',
  'Content' => 'Contenu',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Ordre de tri par défaut: 100, 200, 300, ...',
  'Delete' => 'Supprimer',
  'Next' => 'Suivant',
  'Page title' => 'Titre de la page',
  'Save' => 'Enregistrer',
  'Sort Order' => 'Ordre de tri',
  'URL' => 'URL',
);
