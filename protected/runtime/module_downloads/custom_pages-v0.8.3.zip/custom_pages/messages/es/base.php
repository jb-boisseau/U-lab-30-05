<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => 'Permite añadir páginas (markdown, iframe o enlaces) a la navegación del espacio',
  'Create new Page' => 'Crear nueva página',
  'Custom Pages' => 'Páginas personalizadas',
  'Custom pages' => 'Páginas personalizadas',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navegación',
  'No custom pages created yet!' => '¡No se han creado páginas personalizadas todavía!',
  'Sort Order' => 'Orden de clasificación',
  'Title' => 'Título',
  'Top Navigation' => 'Navegación superior',
  'Type' => 'Tipo',
  'User Account Menu (Settings)' => 'Menú de cuenta de usuario (ajustes)',
  'Without adding to navigation (Direct link)' => 'Sin añadir a la navegación (enlace directo)',
);
