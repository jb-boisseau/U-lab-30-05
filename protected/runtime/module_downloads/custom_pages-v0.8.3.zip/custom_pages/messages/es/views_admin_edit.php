<?php
return array (
  '<strong>Create</strong> page' => '<strong>Crear</strong> página',
  '<strong>Edit</strong> page' => '<strong>Editar</strong> página',
  'Content' => 'Contenido',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Esquema de organización: 100, 200, 300, ...',
  'Delete' => 'Borrar',
  'Next' => 'Siguiente',
  'Page title' => 'Título de página',
  'Save' => 'Guardar',
  'Sort Order' => 'Orden de clasificación',
  'URL' => 'URL',
);
