<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => 'Permite adicionar páginas (markdown, iframe ou links) na navegação do espaço',
  'Create new Page' => 'Criar nova página',
  'Custom Pages' => 'Páginas Personalizadas',
  'Custom pages' => 'Páginas personalizadas',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navegação',
  'No custom pages created yet!' => 'Não há páginas personalizadas criadas ainda!',
  'Sort Order' => 'Ordem de Classificação',
  'Title' => 'Título',
  'Top Navigation' => 'Menu Superior',
  'Type' => 'Tipo',
  'User Account Menu (Settings)' => 'Menu de Conta do Usuário (Configurações)',
  'Without adding to navigation (Direct link)' => 'Sem adicionar à navegação (Link direto)',
);
