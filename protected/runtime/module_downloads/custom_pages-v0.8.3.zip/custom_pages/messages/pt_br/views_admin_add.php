<?php
return array (
  '<strong>Add</strong> new page' => '<strong>Adicionar</strong> nova página',
);
