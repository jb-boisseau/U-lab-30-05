<?php
return array (
  '<strong>Create</strong> page' => '<strong>Criar</strong> página',
  '<strong>Edit</strong> page' => '<strong>Alterar</strong> página',
  'Content' => 'Conteúdo',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Ordenação padrão: 100, 200, 300, ...',
  'Delete' => 'Apagar',
  'Next' => 'Próximo',
  'Page title' => 'Título da página',
  'Save' => 'Salvar',
  'Sort Order' => 'Ordem de Classificação',
  'URL' => 'Endereço',
);
