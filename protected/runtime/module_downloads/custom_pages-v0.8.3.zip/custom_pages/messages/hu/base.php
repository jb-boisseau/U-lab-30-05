<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => '',
  'Create new Page' => '',
  'Custom Pages' => 'Saját oldalak',
  'Custom pages' => '',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => '',
  'No custom pages created yet!' => '',
  'Sort Order' => '',
  'Title' => '',
  'Top Navigation' => '',
  'Type' => '',
  'User Account Menu (Settings)' => '',
  'Without adding to navigation (Direct link)' => '',
);
