<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => 'Hiermee kunt u pagina\'s (markdown, iframe of links) toevoegen aan de ruimtenavigatie',
  'Create new Page' => 'Nieuwe pagina',
  'Custom Pages' => 'Aangepaste pagina\'s',
  'Custom pages' => 'Aangepaste pagina\'s',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'Markdown',
  'Navigation' => 'Navigatie',
  'No custom pages created yet!' => 'Geen aangepaste pagina\'s tot nu toe!',
  'Sort Order' => 'Sorteervolgorde',
  'Title' => 'Titel',
  'Top Navigation' => 'Hoofd navigatie',
  'Type' => 'Type',
  'User Account Menu (Settings)' => 'Gebruikers account menu (Opties) ',
  'Without adding to navigation (Direct link)' => 'Zonder aan navigatie toe te voegen (Directe link)',
);
