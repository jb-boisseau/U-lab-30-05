<?php
return array (
  'Open page...' => 'Open bladzijde...',
);
