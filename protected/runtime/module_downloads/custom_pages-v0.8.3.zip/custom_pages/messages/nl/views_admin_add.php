<?php
return array (
  '<strong>Add</strong> new page' => '<strong>Voeg</strong> nieuwe pagina toe',
);
