<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 01:53
 */
return array (
    '<strong>Add</strong> {templateName} item' => '<strong>Hinzufügen</strong> von {templateName} Element',
    '<strong>Edit</strong> container item' => '<strong>Editiere</strong> Container Element',
);