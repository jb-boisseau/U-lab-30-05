<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 04:09
 */
return array (
    'Create new {label}' => '{label} erstellen',
    'This page lists all available {label} entries.' => 'Diese Seite zeigt alle verfügbaren <strong>{label}</strong> Elemente an.',
    'No {label} entry created yet!' => '<strong>{label}</strong> bisher nicht vorhanden!',
    'page' => 'Inhalt',
    'snippet' => 'Schnipsel',
    'layout' => 'Layout',
);