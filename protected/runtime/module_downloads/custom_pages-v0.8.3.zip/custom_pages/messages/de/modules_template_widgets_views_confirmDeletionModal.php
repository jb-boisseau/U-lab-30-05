<?php
return array (
  'Are you sure you want to delete this container item?' => 'Willst du dieses Container Element wirklich löschen?',
);
