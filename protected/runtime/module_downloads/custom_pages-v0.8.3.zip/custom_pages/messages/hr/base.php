<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => 'Omogućuje dodavanje stranica (označavanje, iframe ili veze) na prostornu navigaciju',
  'Create new Page' => 'Kreiraj novu stranicu',
  'Custom Pages' => 'Prilagođene stranice',
  'Custom pages' => 'Prilagođene stranice',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Poveznica',
  'MarkDown' => 'Smanjenje',
  'Navigation' => 'Navigacija',
  'No custom pages created yet!' => 'Nema prilagođenih stranica!',
  'Sort Order' => 'Redoslijed',
  'Title' => 'Naziv',
  'Top Navigation' => 'Top navigacija',
  'Type' => 'Vrsta',
  'User Account Menu (Settings)' => 'Izbornik korisničkog računa (Postavke)',
  'Without adding to navigation (Direct link)' => 'Bez dodavanja u navigaciju (izravna veza)',
);
