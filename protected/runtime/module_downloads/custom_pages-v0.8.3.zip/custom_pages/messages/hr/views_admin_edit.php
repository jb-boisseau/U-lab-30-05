<?php
return array (
  '<strong>Create</strong> page' => '<strong>Kreiraj</strong> stranicu',
  '<strong>Edit</strong> page' => '<strong>Uredi</strong> stranicu',
  'Content' => 'Sadržaj',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Zadana shema slaganja: 100, 200, 300, ...',
  'Delete' => 'Obriši',
  'Next' => 'Dalje',
  'Page title' => 'Naziv stranice',
  'Save' => 'Spremi',
  'Sort Order' => 'Poredaj red',
  'URL' => 'URL',
);
