<?= $form->field($model, 'content')->textInput(['maxlength' => 255])->label(false) ?>
