<?php
return array (
  'Save and close' => 'Enregistrer et Fermer',
);
