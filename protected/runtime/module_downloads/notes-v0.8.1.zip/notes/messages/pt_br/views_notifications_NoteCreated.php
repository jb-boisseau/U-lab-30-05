<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} criou uma nova nota e atribuiu a você.',
);
