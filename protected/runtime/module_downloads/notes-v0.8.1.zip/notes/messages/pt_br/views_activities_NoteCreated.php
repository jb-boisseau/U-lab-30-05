<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} criou uma nova nota ({noteName}).',
);
