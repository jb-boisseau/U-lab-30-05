<?php
return array (
  'Etherpad API Key' => 'Etherpad API Anahtarı',
  'URL to Etherpad' => 'Etherpad linki',
);
