<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} kullanıcı {spaceName} bulunan not üzerinde çalıştı.',
);
