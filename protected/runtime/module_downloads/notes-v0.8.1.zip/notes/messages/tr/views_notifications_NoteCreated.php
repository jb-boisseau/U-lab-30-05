<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} sizin için yeni bir not oluşturdu.',
);
