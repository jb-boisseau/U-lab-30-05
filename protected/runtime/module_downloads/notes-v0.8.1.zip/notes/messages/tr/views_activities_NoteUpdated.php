<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} kullanıcı {noteName} not üzerinde çalıştı.',
);
