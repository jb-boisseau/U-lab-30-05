<?php
return array (
  'Open note' => 'Otwórz notatkę ',
);
