<?php
return array (
  'Save and close' => 'Zapisz i zamknij',
);
