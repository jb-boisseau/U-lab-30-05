<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} pracował nad notatką {spaceName}.',
);
