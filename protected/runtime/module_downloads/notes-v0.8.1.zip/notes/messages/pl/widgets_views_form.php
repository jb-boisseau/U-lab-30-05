<?php
return array (
  'Title of your new note' => 'Tytuł nowej notatki ',
);
