<?php
return array (
  'Notes' => 'Notater',
);
