<?php
return array (
  'Title of your new note' => 'Kop van uw nieuwe notitie',
);
