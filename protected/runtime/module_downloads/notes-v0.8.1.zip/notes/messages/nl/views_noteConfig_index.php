<?php
return array (
  'API Connection successful!' => 'API verbinding is succesvol.',
  'Back to modules' => 'Terug naar modules',
  'Could not connect to API!' => 'Kan niet verbinden met AP.',
  'Current Status:' => 'Huidige status:',
  'Notes Module Configuration' => 'Notitie module configuratie',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Lees de module documentatie in /protected/modules/notes/docs/install.txt voor meer details!',
  'Save & Test' => 'Bewaar & Test',
  'The notes module needs a etherpad server up and running!' => 'The notitiemodule heeft een draaide ehterpad server nodig.',
  'e.g. http://yourdomain/pad/' => 'Bijvoorbeeld hppt://uwdomein/pad/',
);
