<?php
return array (
  'Open note' => 'Open de notitie',
);
