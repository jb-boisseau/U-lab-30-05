<?php
return array (
  'Notes' => 'Notities',
);
