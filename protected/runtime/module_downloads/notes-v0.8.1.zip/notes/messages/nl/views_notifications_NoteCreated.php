<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} heeft een nieuwe notitie gemaakt en aan u toegewezen.',
);
