<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName}  heeft gewerkt aan notitie {spaceName}.',
);
