<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} dirbo su pastaba {spaceName}.',
);
