<?php
return array (
  'Notes' => 'Pastabos',
);
