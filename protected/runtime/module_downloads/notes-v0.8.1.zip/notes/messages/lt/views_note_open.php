<?php
return array (
  'Save and close' => 'Išsaugoti ir uždaryti',
);
