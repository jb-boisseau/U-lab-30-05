<?php
return array (
  'Open note' => 'Atidaryti pastabą',
);
