<?php
return array (
  'Etherpad API Key' => 'Etherpad API Key',
  'URL to Etherpad' => 'URL zur Etherpad Installation',
);
