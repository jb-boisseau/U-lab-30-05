<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} hat die Notiz »{noteName}« erstellt.',
);
