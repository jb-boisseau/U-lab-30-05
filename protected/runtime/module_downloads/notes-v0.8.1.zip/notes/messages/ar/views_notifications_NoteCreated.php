<?php
return array (
  '{userName} created a new note and assigned you.' => '',
);
