<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '',
);
