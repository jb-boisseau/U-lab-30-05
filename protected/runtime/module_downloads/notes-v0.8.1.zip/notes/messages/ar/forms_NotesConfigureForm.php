<?php
return array (
  'Etherpad API Key' => '',
  'URL to Etherpad' => '',
);
