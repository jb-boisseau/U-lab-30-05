<?php
return array (
  'Title of your new note' => '',
);
