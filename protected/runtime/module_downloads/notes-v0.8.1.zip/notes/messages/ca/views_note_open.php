<?php
return array (
  'Save and close' => 'Desar i eliminar',
);
