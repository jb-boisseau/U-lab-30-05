<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} actualizó la nota {noteName}.',
);
