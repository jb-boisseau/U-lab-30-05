<?php
return array (
  'Save and close' => 'Guardar y cerrar',
);
