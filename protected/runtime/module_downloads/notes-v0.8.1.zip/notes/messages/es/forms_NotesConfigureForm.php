<?php
return array (
  'Etherpad API Key' => 'Clave de API de Etherpad',
  'URL to Etherpad' => 'URL a Etherpad',
);
