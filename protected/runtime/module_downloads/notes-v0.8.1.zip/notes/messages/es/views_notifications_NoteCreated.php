<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} creó una nota y la asignó a ti.',
);
