<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} actualizó la nota {spaceName}.',
);
