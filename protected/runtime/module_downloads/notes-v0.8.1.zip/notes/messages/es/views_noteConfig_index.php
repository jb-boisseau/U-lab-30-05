<?php
return array (
  'API Connection successful!' => '¡Conexión con éxito con la API!',
  'Back to modules' => 'Volver a módulos',
  'Could not connect to API!' => '¡No se puedo conectar con la API!',
  'Current Status:' => 'Estado actual:',
  'Notes Module Configuration' => 'Configuración del módulo de notas',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Por favor, lee la documentación del módulo en /protected/modules/notes/docs/install.txt para mas detalles.',
  'Save & Test' => 'Guardar y probar',
  'The notes module needs a etherpad server up and running!' => '¡Este módulo de notas necesita un servidor Etherpad listo y funcionando!',
  'e.g. http://yourdomain/pad/' => 'p.ej. http://yourdomain/pad/',
);
