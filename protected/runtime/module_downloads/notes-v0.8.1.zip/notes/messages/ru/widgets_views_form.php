<?php
return array (
  'Title of your new note' => 'Заголовок вашей новой заметки',
);
