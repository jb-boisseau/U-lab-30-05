<?php
return array (
  'Etherpad API Key' => 'API klíč pro Etherpad',
  'URL to Etherpad' => 'URL k Etherpadu',
);
