<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} napsal(a) novou poznámku {noteName}.',
);
