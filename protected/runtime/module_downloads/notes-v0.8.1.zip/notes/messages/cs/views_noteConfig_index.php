<?php
return array (
  'API Connection successful!' => 'Připojení k API bylo úspěšné!',
  'Back to modules' => 'Zpět na přehled modulů',
  'Could not connect to API!' => 'Nebylo možné se připojit k API!',
  'Current Status:' => 'Aktuální stav:',
  'Notes Module Configuration' => 'Nastavení modulu Poznámky',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Pro více informací si prosím přečtěte dokumentaci modulu v /protected/modules/notes/docs/install.txt',
  'Save & Test' => 'Uložit a vyzkoušet',
  'The notes module needs a etherpad server up and running!' => 'Modul Poznámky vyžaduje ke svému provozu běžící etherpad server!',
  'e.g. http://yourdomain/pad/' => 'například: http://vasedomena.cz/poznamky',
);
