<?php
return array (
  'Save and close' => 'Uložit a zavřít',
);
