<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} har arbejdet på notatet {noteName}.',
);
