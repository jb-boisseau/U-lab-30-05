<?php
return array (
  'Notes' => 'Бележки',
);
