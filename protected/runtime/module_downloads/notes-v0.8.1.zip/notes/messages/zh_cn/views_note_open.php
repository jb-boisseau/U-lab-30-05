<?php
return array (
  'Save and close' => '保存并关闭',
);
