<?php
return array (
  'Etherpad API Key' => 'Chiave Etherpad API ',
  'URL to Etherpad' => 'URL a Etherpad',
);
