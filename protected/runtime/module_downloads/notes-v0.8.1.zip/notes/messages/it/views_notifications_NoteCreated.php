<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} ha creato una nuova nota e l\'ha assegnata a te.',
);
