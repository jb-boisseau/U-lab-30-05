<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} ha creato una nuova nota {noteName}.',
);
