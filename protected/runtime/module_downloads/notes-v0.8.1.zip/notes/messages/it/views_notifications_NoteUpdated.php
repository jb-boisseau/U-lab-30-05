<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} ha lavorato sulla nota {spaceName}.',
);
