<?php
return array (
  'Open note' => 'بازکردن یادداشت',
);
