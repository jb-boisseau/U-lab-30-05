<?php
return array (
  'Title of your new note' => 'عنوان یادداشت جدید شما',
);
