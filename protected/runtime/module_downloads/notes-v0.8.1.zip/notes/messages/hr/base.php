<?php
return array (
  'Notes' => 'Bilješke',
);
