<?php
return array (
  'API Connection successful!' => 'API konekcija uspješna!',
  'Back to modules' => 'Povratak na module',
  'Could not connect to API!' => 'Nije se moguće spojiti na API!',
  'Current Status:' => 'Trenutačni status:',
  'Notes Module Configuration' => 'Konfiguracija modula bilješki',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Pročitajte dokumentaciju modula pod /protected/modules/notes/docs/install.txt za više detalja!',
  'Save & Test' => 'Spremi & testiraj',
  'The notes module needs a etherpad server up and running!' => 'Modul bilješku treba etherpad server!',
  'e.g. http://yourdomain/pad/' => 'e.g. http://yourdomain/pad/',
);
