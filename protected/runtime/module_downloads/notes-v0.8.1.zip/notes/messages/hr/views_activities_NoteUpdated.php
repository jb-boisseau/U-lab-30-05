<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} je radio na bilješci {noteName}.',
);
