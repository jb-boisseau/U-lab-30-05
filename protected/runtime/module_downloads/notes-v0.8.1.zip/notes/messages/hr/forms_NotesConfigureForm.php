<?php
return array (
  'Etherpad API Key' => 'API ključ Etherpada',
  'URL to Etherpad' => 'URL prema Etherpad',
);
