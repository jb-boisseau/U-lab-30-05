<?php
return array (
  'Title of your new note' => 'Naslov vaše nove bilješke',
);
