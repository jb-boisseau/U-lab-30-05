<?php
return array (
  'Open note' => 'Otvori bilješku',
);
