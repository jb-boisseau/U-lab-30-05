<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} kreirao je novu bilješku i dodijelio je vama.',
);
