<?php
return array (
  'Save and close' => 'Spremi i zatvori',
);
