<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} kreirao je novu bilješku {noteName}.',
);
