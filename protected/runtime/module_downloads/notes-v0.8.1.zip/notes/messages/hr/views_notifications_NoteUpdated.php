<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} je radio na bilješci {spaceName}.',
);
