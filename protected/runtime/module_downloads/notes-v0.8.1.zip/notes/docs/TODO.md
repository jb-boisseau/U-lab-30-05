ToDos / Wishlist
================

- Send activity when note was changed
- Add ability to modify note title
- Add ability to modify user color

