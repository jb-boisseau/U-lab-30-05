Changelog
=========

0.8.1 - 27 March, 2018
----------------------
>Note: The pad.css has changed. Please replace it in your Etherpad installation.

- Enh: Show version history and chat 


0.8.0 - 15 March, 2018
----------------------
- Enh: Improved random color generation
- Enh: Switched to new Button API
- Fix: Wall entry background
- Chg: Resources path from assets -> resources

