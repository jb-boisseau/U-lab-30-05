OnlyOffice - DocumentServer Integration
=======================================

## Description
Collaboratively view and edit office documents (Word, Excel or PowerPoint) in real-time.

You can find more information about the OnlyOffice Document Server (Integration) installation here:  <http://helpcenter.onlyoffice.com/server/document.aspx>

> Note: This module requires a running OnlyOffice DocumentServer instance.

__Module website:__ <https://github.com/humhub/humhub-modules-onlydocuments>    
__Author:__ luke, buddha

## Changelog

<https://github.com/humhub/humhub-modules-onlydocuments/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-onlydocuments/issues>
