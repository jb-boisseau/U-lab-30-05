Changelog
=========


1.0.1  (May 08, 2018)
-----------------------
- Enh: Updated translations
