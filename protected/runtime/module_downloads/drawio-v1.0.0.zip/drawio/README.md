draw.io - Diagrams
==================

## Description

Create or edit diagrams using the draw.io editor integration.

__Module website:__ <https://github.com/humhub/humhub-modules-drawio>    
__Author:__ humhub

## Changelog

<https://github.com/humhub/humhub-modules-drawio/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-drawio/issues>
