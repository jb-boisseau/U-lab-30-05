<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Anulează',
  'Polls' => '',
  'Save' => 'Salvează',
);
