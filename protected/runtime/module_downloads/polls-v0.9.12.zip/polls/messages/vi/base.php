<?php
return array (
  'Allows to start polls.' => 'Cho phép khởi tạo biểu quyết',
  'Cancel' => 'Hủy',
  'Polls' => 'Biểu quyết',
  'Save' => 'Lưu',
);
