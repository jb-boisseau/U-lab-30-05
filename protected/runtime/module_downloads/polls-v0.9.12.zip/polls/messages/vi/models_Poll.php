<?php
return array (
  'Answers' => 'Trả lời',
  'Multiple answers per user' => 'Cho phép biểu quyết với nhiều hơn một phương án lựa chọn',
  'Please specify at least {min} answers!' => 'Vui lòng chỉ định ít nhất  {min} câu trả lời!',
  'Question' => 'Câu hỏi',
);
