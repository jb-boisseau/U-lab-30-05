<?php
return array (
  'Access denied!' => 'Acceso denegado!',
  'Anonymous poll!' => 'Encuesta anónima!',
  'Could not load poll!' => '¡No se pudo cargar la votación!',
  'Invalid answer!' => '¡Respuesta no válida!',
  'Users voted for: <strong>{answer}</strong>' => 'Los usuarios votaron por: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => '¡Votar múltiples respuestas esta deshabilitado!',
  'You have insufficient permissions to perform that operation!' => '¡No tienes suficientes permisos para hacer esa operación!',
);
