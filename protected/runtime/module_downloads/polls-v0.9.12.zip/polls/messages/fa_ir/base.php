<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'انصراف',
  'Polls' => 'نظرسنجی‌ها',
  'Save' => 'ذخیره',
);
