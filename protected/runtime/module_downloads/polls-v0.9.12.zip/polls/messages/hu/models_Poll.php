<?php
return array (
  'Answers' => 'Válaszok',
  'Multiple answers per user' => 'Egy felhasználó többet is választhat',
  'Please specify at least {min} answers!' => 'Kérlek határozz meg legalább {min} választ!',
  'Question' => 'Szavazás',
);
