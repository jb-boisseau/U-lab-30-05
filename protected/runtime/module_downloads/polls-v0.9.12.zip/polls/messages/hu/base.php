<?php
return array (
  'Allows to start polls.' => 'Engedélyezi szavazás indítását.',
  'Cancel' => 'Mégsem',
  'Polls' => 'Szavazás',
  'Save' => 'Mentés',
);
