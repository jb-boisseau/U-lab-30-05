<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>NIncs még szavazás!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Nincs még szavazás!</b><br> Légy Te az első aki létrehoz egyet...',
  'Asked by me' => 'Én kérdeztem',
  'No answered yet' => 'Nincs megválaszolva',
  'Only private polls' => 'Csak privát szavazások',
  'Only public polls' => 'Csak nyilvános szavazások',
);
