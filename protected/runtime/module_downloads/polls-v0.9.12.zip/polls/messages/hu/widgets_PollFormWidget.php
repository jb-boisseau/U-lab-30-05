<?php
return array (
  'Ask' => 'Szavazás mentése',
);
