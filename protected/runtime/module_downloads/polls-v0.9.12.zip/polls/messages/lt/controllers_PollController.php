<?php
return array (
  'Access denied!' => 'Prieiga negalima!',
  'Anonymous poll!' => '',
  'Could not load poll!' => 'Nepavyko įkelti apklausos!',
  'Invalid answer!' => 'Negalimas atsakymas!',
  'Users voted for: <strong>{answer}</strong>' => 'Vartotojai balsavo už: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Negalima pasirinkti kelių atsakymų!',
  'You have insufficient permissions to perform that operation!' => 'Jūs neturite teisių atlikti šį veiksmą!',
);
