<?php
return array (
  'Answers' => 'Atbildes',
  'Multiple answers per user' => 'Vairākas atbildes no lietotāja',
  'Please specify at least {min} answers!' => 'Lūdzu norādi vismaz {min} atbildes!',
  'Question' => 'Jautājums',
);
