<?php
return array (
  'Ask' => 'Perguntar',
);
