<?php
return array (
  'Allows to start polls.' => 'Permite iniciar enquetes.',
  'Cancel' => 'Cancelar',
  'Polls' => 'Enquete',
  'Save' => 'Salvar',
);
