<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => '',
  'Polls' => '',
  'Save' => 'Guardar',
);
