<?php
return array (
  'Ask' => 'Pregunta',
);
