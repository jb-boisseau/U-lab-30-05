<?php
return array (
  'Ask' => '发起',
);
