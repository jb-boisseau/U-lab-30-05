<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Avbryt',
  'Polls' => '',
  'Save' => 'Spara',
);
