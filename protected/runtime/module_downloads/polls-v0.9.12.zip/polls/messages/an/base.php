<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Cancelar',
  'Polls' => '',
  'Save' => 'Uložit',
);
