<?php
return array (
  'Allows to start polls.' => 'アンケートの開始を許可する',
  'Cancel' => 'キャンセル',
  'Polls' => 'アンケート',
  'Save' => '保存',
);
