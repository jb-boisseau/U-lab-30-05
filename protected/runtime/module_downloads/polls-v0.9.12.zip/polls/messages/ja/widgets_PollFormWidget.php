<?php
return array (
  'Ask' => '質問する',
);
