<?php
return array (
  '{userName} answered the {question}.' => 'Uživatel {userName} odpověděl na otázku {question}',
);
