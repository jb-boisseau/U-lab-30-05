<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} hat eine Umfrage erstellt und dir zugewiesen.',
);
