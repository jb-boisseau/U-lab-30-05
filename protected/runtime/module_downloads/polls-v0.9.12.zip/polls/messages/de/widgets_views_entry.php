<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Hinweis:</strong> Das Ergebnis wird erst angezeigt, sobald ein Moderator die Umfrage geschlossen hat.',
  'Anonymous' => 'Anonym',
  'Closed' => 'Beendet',
  'Complete Poll' => 'Umfrage abschliessen',
  'Reopen Poll' => 'Umfrage wieder öffnen',
  'Reset my vote' => 'Meine Abstimmung zurücksetzen',
  'Vote' => 'Abstimmen',
  'and {count} more vote for this.' => 'und {count} mehr stimmten hierfür ab.',
  'votes' => 'Stimmen',
);
