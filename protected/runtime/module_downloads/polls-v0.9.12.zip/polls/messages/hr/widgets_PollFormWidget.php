<?php
return array (
  'Ask' => 'Pitaj',
);
