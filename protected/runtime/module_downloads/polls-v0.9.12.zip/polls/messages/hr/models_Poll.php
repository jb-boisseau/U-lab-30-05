<?php
return array (
  'Answers' => 'Odgovori',
  'Multiple answers per user' => 'Višestruki odgovori po korisniku',
  'Please specify at least {min} answers!' => 'Molimo odaberite barem {min} odgovora!',
  'Question' => 'Pitanje',
);
