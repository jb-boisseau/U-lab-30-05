<?php
return array (
  'Allows to start polls.' => 'Ce module permet de créer des sondages.',
  'Cancel' => 'Annuler',
  'Polls' => 'Sondages',
  'Save' => 'Enregistrer',
);
