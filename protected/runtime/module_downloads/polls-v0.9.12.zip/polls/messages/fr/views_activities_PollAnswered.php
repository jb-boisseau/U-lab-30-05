<?php
return array (
  '{userName} answered the {question}.' => '{userName} a répondu à {question}.',
);
