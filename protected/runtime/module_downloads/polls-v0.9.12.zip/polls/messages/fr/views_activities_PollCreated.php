<?php
return array (
  '{userName} created a new {question}.' => '{userName} a créé un sondage : {question}.',
);
