<?php
return array (
  'Access denied!' => 'Accesso negato!',
  'Anonymous poll!' => 'Sondaggio anonimo!',
  'Could not load poll!' => 'Non posso caricare il sondaggio!',
  'Invalid answer!' => 'Risposta non valida!',
  'Users voted for: <strong>{answer}</strong>' => 'Gli utenti hanno votato per: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Il voto per risposte multiple è disabilitato!',
  'You have insufficient permissions to perform that operation!' => 'Non hai i permessi sufficienti per eseguire questa operazione!',
);
