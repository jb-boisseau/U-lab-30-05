<?php
return array (
  'Answers' => 'Svar',
  'Multiple answers per user' => 'Flere svar pr bruger',
  'Please specify at least {min} answers!' => 'Venligst specificer mindst {min} svar!',
  'Question' => 'Spørgsmål',
);
