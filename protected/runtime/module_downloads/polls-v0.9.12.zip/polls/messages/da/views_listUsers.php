<?php
return array (
  'User who vote this' => 'Bruger som stemte dette',
);
