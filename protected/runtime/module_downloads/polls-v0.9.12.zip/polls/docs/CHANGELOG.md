Changelog
=========

0.9.12 - 17 April, 2018
------------------------

- Enh: Updated translations


0.9.11 - 12 April, 2018
------------------------

- Enh: Added `Hide results until poll is closed?` option.



