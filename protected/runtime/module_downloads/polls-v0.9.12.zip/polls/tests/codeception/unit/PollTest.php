<?php

namespace tests\codeception\unit\modules\breakingnews;

use tests\codeception\_support\HumHubDbTestCase;

class PollTest extends HumHubDbTestCase
{

}
