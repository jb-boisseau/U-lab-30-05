Changelog
=========

1.0.8  (December 20, 2017)
---------------------------

- Fix: Guest access write check
- Enh: Updated translations

