<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Les meves</strong> tasques',
  'From space: ' => 'De l\'espai:',
);
