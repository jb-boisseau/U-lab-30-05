<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Anulează',
  'Deadline' => '',
  'Save' => 'Salvează',
  'What is to do?' => '',
);
