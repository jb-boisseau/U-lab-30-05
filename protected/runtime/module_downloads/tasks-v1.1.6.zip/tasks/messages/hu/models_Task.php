<?php
return array (
  'Task' => 'Feladat',
);
