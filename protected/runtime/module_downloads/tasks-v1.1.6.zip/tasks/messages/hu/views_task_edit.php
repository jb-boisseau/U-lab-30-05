<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Mégsem',
  'Deadline' => 'Határidő',
  'Save' => 'Mentés',
  'What is to do?' => '',
);
