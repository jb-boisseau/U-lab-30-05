<?php
return array (
  'Assigned user(s)' => 'Dodijeljeni korisnik(ci)',
  'Deadline' => 'Krajnji rok',
  'Tasks' => 'Zadaci',
  'Title' => 'Naziv',
);
