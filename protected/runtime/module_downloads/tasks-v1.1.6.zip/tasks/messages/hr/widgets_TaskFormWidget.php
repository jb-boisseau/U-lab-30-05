<?php
return array (
  'Create' => 'Kreiraj',
);
