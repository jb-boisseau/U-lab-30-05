<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Moji</strong> zadaci',
  'From space: ' => 'Iz prostora:',
);
