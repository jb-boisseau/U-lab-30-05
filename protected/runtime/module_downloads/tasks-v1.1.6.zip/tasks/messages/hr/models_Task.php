<?php
return array (
  'Task' => 'Zadatak',
);
