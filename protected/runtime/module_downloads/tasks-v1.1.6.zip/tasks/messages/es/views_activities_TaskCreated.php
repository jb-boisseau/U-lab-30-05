<?php
return array (
  '{userName} created task {task}.' => '{userName} creó la tarea {task}.',
);
