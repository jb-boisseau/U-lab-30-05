<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} asignado a tarea {task}.',
);
