<?php
return array (
  '{userName} created a new task {task}.' => '{userName} a créé la tâche {task}.',
);
