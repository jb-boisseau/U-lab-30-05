<?php
return array (
  'Assigned user(s)' => 'Utilisateur(s) affecté(s)',
  'Deadline' => 'Échéance',
  'Tasks' => 'Tâches',
  'Title' => 'Titre',
);
