<?php
return array (
  'Assign users to this task' => 'Affecter des utilisateurs à cette tâche',
  'Deadline for this task?' => 'Date limite pour cette tâche ?',
  'Preassign user(s) for this task.' => 'Pré-affecter des utilisateurs à cette tâche.',
  'What to do?' => 'Qu\'y a t-il à faire ?',
);
