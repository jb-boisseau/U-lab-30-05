<?php
return array (
  'Could not access task!' => 'Negalima užduoties prieiga!',
);
