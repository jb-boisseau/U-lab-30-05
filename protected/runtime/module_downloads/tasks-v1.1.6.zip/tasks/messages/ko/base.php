<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => '',
  'Title' => '제목',
);
