<?php
return array (
  'Assigned user(s)' => 'Přiřazený uživatel/é',
  'Deadline' => 'Lhůta',
  'Tasks' => 'Úkoly',
  'Title' => 'Název',
);
