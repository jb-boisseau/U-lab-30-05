<?php
return array (
  'Could not access task!' => 'Nelze získat přístup k úkolu!',
);
