<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Potvrdit</strong> smazání',
  'Add Task' => 'Přidat úkol',
  'Cancel' => 'Zrušit',
  'Delete' => 'Smazat',
  'Do you really want to delete this task?' => 'Opravdu chcete smazat tento úkol?',
  'No open tasks...' => 'Žádné otevřené úlohy ..',
  'completed tasks' => 'dokončené úkoly',
);
