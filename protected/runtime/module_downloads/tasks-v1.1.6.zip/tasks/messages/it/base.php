<?php
return array (
  'Assigned user(s)' => 'Utente/i assegnato/i',
  'Deadline' => 'Scadenza',
  'Tasks' => 'Attività',
  'Title' => 'Titolo',
);
