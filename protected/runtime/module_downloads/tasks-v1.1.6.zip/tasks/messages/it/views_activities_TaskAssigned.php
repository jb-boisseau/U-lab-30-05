<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} assegnato all\'attività {task}.',
);
