<?php
return array (
  'Assign users to this task' => 'Przypisz użytkowników do tego zadania',
  'Deadline for this task?' => 'Termin końcowy zadania?',
  'Preassign user(s) for this task.' => 'Przypisz wstępnie użytkowników do tego zadania.',
  'What to do?' => 'Co jest do zrobienia? ',
);
