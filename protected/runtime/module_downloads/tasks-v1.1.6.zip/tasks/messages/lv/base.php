<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => '',
  'Title' => 'Nosaukums',
);
