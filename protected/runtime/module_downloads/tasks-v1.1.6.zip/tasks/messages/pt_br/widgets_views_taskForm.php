<?php
return array (
  'Assign users to this task' => 'Atribuir usuários para esta tarefa',
  'Deadline for this task?' => 'Prazo para esta tarefa?',
  'Preassign user(s) for this task.' => 'Pré-atribuir usuários para esta tarefa.',
  'What to do?' => 'O que fazer?',
);
