<?php
return array (
  'Assigned user(s)' => 'Usuário(s) atribuído(s)',
  'Deadline' => 'Prazo',
  'Tasks' => 'Tarefas',
  'Title' => 'Título',
);
