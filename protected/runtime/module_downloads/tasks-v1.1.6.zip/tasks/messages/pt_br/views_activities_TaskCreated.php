<?php
return array (
  '{userName} created task {task}.' => '{userName} criou a tarefa {task}.',
);
