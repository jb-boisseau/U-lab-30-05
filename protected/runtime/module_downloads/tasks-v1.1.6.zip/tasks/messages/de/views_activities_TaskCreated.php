<?php
return array (
  '{userName} created task {task}.' => '{userName} hat die Aufgabe »{task}« angelegt.',
);
