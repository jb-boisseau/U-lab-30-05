<?php
return array (
  'Anyone can work on this task!' => 'Jeder kann an dieser Aufgabe arbeiten',
  'This task can only be processed by assigned and responsible users.' => 'Diese Aufgabe kann nur von zugewiesenen und verantwortlichen Benutzern bearbeitet werden.',
  'Open Task' => 'Zur Aufgabe',


);

