<?php
return array (
  '<strong>Create</strong> new task' => 'Neue Aufgabe <strong>erstellen</strong>',
  '<strong>Edit</strong> task' => 'Aufgabe <strong>bearbeiten</strong>',
  'Basic' => 'Basis',
   'Scheduling' => 'Zeitbasiert',
    'Assignment' => 'Zuweisung',
    'Checklist' => 'Checkliste',
    'Files' => 'Dateien',
    'Assign users' => 'Person zuweisen',
      'Leave empty to let anyone work on this task.' => 'Leer lassen, damit alle an der Aufgabe arbeiten können',
      'Add responsible users' => 'Verantwortliche Person hinzufügen',
     'Add checkpoint...' => 'Teilaufgabe hinzufügen',
  'Add reminder' => 'Erinnerung hinzufügen',
  

);