<?php
return array (
  'Create' => 'Erstellen',
    'Assignment' => 'Zuweisung',


);
