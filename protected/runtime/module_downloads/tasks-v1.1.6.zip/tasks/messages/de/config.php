<?php
return array (
  'Show snippet' => 'Zeige das Widget',
    'Show snippet in Space' => 'Zeige das Widget im Space',


    'Max tasks items' => 'Maximale Aufgabenelemente',


    'Sort order' => 'Sortieren',






);