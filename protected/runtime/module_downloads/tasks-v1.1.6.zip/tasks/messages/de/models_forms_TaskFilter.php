<?php
return array (
  'Filter tasks' => 'Aufgaben filtern',
  'Overdue' => 'Überfällig',
  'I\'m assigned' => 'Ich wurde zugewiesen',
  'I\'m responsible' => 'Ich bin verantwortlich',
  'Created by me' => 'Von mir erstellt',
  'End time must be after start time!' => 'Das Ende muss nach dem Beginn sein!',  
  'Start Date' => 'Startdatum',
  'Event Type' => 'Typ',
  'End Date' => 'Enddatum',
  'Start Time' => 'Startzeit',
  'End Time' => 'Endzeit',
  'Time Zone' => 'Zeitzone',
  'Public' => 'Öffentlich',
  'Status' => 'Status',
);


