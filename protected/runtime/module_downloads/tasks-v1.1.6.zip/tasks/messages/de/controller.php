<?php
return array (
  'You have insufficient permissions to perform that operation!' => 'keine ausreichenden Rechte',
    'Already requested' => 'Wurde bereits angefordert',

  'Request sent' => 'Absendung anfordern',



);