<?php
return array (
  'Title' => 'Überschrift',
  'Completed' => 'Fertiggestellt',
);

