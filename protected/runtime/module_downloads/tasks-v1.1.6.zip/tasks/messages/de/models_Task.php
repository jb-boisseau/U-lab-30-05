<?php
return array (
  'Task' => 'Aufgabe',
  'Title' => 'Überschrift',
  'Color' => 'Farbe',
  'Description' => 'Beschreibung',
  'Review by responsible user required' => 'Kontrolle der verantwortlichen Person notwendig',
  'Extend deadline request' => 'Antrag auf Verschiebung der Abgabefrist',
  'All Day' => 'Ganztägig',
  'Start' => 'Start',
  'End' => 'Ende',
  'Status' => 'Status',
  'Add schedule to the space calendar' => 'Zum Space-Kalender hinzufügen',
  'Parent Task' => 'Übergeordnete Aufgabe',
  'Checklist Items' => 'Kontrollpunkte',
  'Responsible user(s)' => 'Verantwortliche Person',
  'Reminders' => 'Erinnerungen',
  'Scheduling' => 'Zeitbasiert',
  'Assigned user(s)' => 'Zugwiesene Personen',
  'Completed' => 'Fertiggestellt',
    'Reminder sent' => 'Erinnerung gesendet',
  'Don\'t add to calendar' => 'Nicht zum Kalender hinzufügen',
    'Add Deadline to space calendar' => 'Frist zum Kalender hinzufügen',
    'Add to space calendar' => 'Zum Space-Kalender hinzufügen',
    'Deadline: ' => 'Frist: ',


);
