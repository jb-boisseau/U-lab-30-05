<?php
return array (
  '<strong>Confirm</strong> deleting' => 'Löschen <strong>bestätigen</strong> ',
  'Add Task' => 'Aufgabe erstellen',
  'Cancel' => 'Abbrechen',
  'Delete' => 'Löschen',
  'Do you really want to delete this task?' => 'Möchtest du diese Aufgabe wirklich löschen?',
  'No open tasks...' => 'Keine offenen Aufgaben...',
  'completed tasks' => 'abgeschlossene Aufgaben',
    'Assignment' => 'Zuweisung',


);
