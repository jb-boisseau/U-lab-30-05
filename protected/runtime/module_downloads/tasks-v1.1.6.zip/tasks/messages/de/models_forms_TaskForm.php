<?php
return array (
  'End time must be after start time!' => 'Das Fristende muss vor dem Start liegen.',
  'Start Date' => 'Startdatum',
  'Event Type' => 'Typ',  
  'End Date' => 'Enddatum',  
  'Start Time' => 'Startzeit',  
  'End Time' => 'Endzeit',
  'Time Zone' => 'Zeitzone',  
  'Public' => 'Öffentlich',  
  
  
    
);
   