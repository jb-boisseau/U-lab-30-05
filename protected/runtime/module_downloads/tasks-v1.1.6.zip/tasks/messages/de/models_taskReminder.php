<?php
return array (
  'At least 1 Hour before' => 'Eine Stunde vorher',
  'At least 2 Hours before' => 'Zwei Stunden vorher',
  '1 Day before' => 'Einen Tag vorher',
  '2 Days before' => 'Zwei Tage vorher', 
  '1 Week before' => '1 Woche vorher',
  '2 Weeks before' => '2 Wochen vorher',
  '3 Weeks before' => '3 Wochen vorher',
  '1 Month before' => 'Einen Monat vorher',   
  'Remind Mode' => 'Erinnerungsmodus',
  'Do not remind' => 'Nicht erinnern',
  'Task' => 'Aufgaben',
);