<?php
return array (
  'Could not access task!' => 'Konnte auf die Aufgabe nicht zugreifen!',
    'Assignment' => 'Zuweisung',
);
