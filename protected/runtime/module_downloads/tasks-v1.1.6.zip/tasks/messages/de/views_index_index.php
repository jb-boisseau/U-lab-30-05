<?php
return array (
  'No Scheduling set for this Task' => 'ohne Frist',
  'Pending' => 'noch unerledigt!',  
  'In Progress' => 'in Bearbeitung',  
   'In Review' => 'in der Kontrolle',
    'Completed' => 'Fertiggestellt',
    'All' => 'Alle',
  
     'Overdue' => 'Überfällig',
       'Today' => 'Heute',

     'Start now, by creating a new task!' => 'Neue Aufgabe erstellen',
       'There are currently no upcoming tasks!.' => 'Keine anstehenden Aufgaben',
       'Filter tasks by title' => 'Aufgaben nach Titel filtern',
  
     'Assigned' => 'Alle',
      'Anyone can work on this task' => 'Jeder kann an der Aufgabe arbeiten',
      'Responsible' => 'Verantwortlich',
    'Drag entry' => 'Eintrag ziehen',
      '<strong>Bestätigung</strong> zur Löschung der Aufgabe' => '<strong>Bestätigung</strong> zur Löschung der Aufgabe',

      '<strong>Confirm</strong> task deletion' => 'Wollen sie die Aufgabe wirklich löschen?',

  'Reset Task' => 'Aufgabe zurücksetzen',

  'No Scheduling set for this Task' => 'ohne Frist',

 'Deadline at' => 'Ende der Frist am',
    



  
 
                          
                          
                          
                          
                          
                          
            
            
);

