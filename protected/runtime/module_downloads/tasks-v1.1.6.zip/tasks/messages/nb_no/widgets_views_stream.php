<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Det er ingen oppgaver enda!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Det er ingen oppgaver enda!</b><br>Vær den første til og lage noen...',
  'Assigned to me' => 'Tildel meg',
  'Back to stream' => 'Tilbake til Nyhetsstrøm',
  'Created by me' => 'Laget av meg',
  'Creation time' => 'Laget dato',
  'Filter' => 'Filter',
  'Last update' => 'Siste oppdatering',
  'No tasks found which matches your current filter(s)!' => 'Ingen oppgaver er funnet som matcher ditt filter (e) !',
  'Nobody assigned' => 'Ingen tilknyttet',
  'Sorting' => 'Sorter',
  'State is finished' => 'Status er fullført',
  'State is open' => 'Status er åpen',
);
