<?php
return array (
  '{userName} created task {task}.' => '{userName} laget oppgave {task}.',
);
