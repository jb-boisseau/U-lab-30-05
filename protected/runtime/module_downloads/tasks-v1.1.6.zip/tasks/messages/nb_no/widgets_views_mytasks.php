<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mine</strong> oppgaver',
  'From space: ' => 'Fra gruppe: ',
);
