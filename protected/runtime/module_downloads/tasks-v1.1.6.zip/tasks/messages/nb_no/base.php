<?php
return array (
  'Assigned user(s)' => 'Tilknyttede bruker (e)',
  'Deadline' => 'Frist',
  'Tasks' => 'Oppgaver',
  'Title' => 'Tittel',
);
