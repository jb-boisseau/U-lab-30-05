<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Er zijn nog geen taken!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Er zijn nog geen taken!</b><br>Wees de eerste en maak er een',
  'Assigned to me' => 'Gekoppeld aan mij',
  'Back to stream' => '@@@@',
  'Created by me' => 'Geaakt door mij',
  'Creation time' => 'Aanmaak datum',
  'Filter' => 'Filter',
  'Last update' => 'Laatste update',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Nobody assigned' => 'Niemand gekoppeld',
  'Sorting' => 'Sortering',
  'State is finished' => 'Status is voltooid',
  'State is open' => 'Status is open',
);
