<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} heeft je aan de taak {task} gekoppeld.',
);
