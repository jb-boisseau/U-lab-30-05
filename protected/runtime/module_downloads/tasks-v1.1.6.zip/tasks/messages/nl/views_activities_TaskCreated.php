<?php
return array (
  '{userName} created task {task}.' => '{userName} heeft de taak {task} gemaakt.',
);
