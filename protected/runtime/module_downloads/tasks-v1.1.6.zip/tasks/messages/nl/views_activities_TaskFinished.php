<?php
return array (
  '{userName} finished task {task}.' => '{userName} heeft de taak {task} voltooid.',
);
