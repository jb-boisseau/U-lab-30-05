<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Nobody assigned' => '',
  'State is finished' => '',
  'State is open' => '',
  'Back to stream' => '@@@@',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Created by me' => 'Criado por mim',
  'Creation time' => 'Hora de Criação',
  'Filter' => 'Filtro',
  'Last update' => 'Última atualização',
  'Sorting' => 'Ordenar',
);
