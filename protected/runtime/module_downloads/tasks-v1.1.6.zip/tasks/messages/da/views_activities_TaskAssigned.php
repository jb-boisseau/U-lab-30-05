<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} tilføjet til opgaven {task}.',
);
