Changelog
=========
1.1.6 (May 25, 2018)
-----------------------
- Fix reminder not sent
- Fix assignment notifications are sent for already existing assignments

1.1.4 (May 24, 2018)
-----------------------
- Fix removed invalid full day span check

1.1.3 (May 24, 2018)
-----------------------
- Fix user list tooltip on task list items

1.1.2 (May 24, 2018)
-----------------------
- Fix user list tooltip on task list items

1.1.1 (May 24, 2018)
-----------------------
- Fix notification and activity module id

1.1.0 (May 23, 2018))
-----------------------
- Enh: Added sortable Task lists
- Enh: Added Task review (staxDB)
- Enh: Added sortable Task checklist (staxDB)
- Enh: Added Task responsible user (staxDB)
- Enh: Extended Permission System 
- Enh: Added Search view
- Enh: Added calendar export (staxDB)
- Enh: Added extended scheduling (staxDB)
- Chg: Major refactoring + redesign
