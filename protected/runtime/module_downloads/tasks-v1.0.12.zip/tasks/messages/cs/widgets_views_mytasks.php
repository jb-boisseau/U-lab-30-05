<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Moje</strong> úkoly',
  'From space: ' => 'Z prostoru:',
);
