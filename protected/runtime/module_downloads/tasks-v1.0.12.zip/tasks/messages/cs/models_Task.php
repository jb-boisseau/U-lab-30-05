<?php
return array (
  'Task' => 'Úkol',
);
