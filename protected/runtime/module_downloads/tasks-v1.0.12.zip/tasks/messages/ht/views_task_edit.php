<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => '',
  'Deadline' => '',
  'Save' => 'Sere',
  'What is to do?' => '',
);
