<?php
return array (
  'Could not access task!' => 'Não foi possível acessar a tarefa!',
);
