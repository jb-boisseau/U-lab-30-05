<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => '',
  'Cancel' => 'Atšaukti',
  'Delete' => 'Ištrinti',
  'Do you really want to delete this task?' => '',
  'No open tasks...' => '',
  'completed tasks' => '',
);
