<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => 'Užduotys',
  'Title' => 'Pavadinimas',
);
