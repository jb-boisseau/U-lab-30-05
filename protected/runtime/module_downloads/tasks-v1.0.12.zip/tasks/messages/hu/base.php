<?php
return array (
  'Assigned user(s)' => 'Hozzárendelt felhasználó(k)',
  'Deadline' => 'Határidő',
  'Tasks' => 'Feladatok',
  'Title' => 'Cím',
);
