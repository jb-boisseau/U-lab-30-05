<?php
return array (
  '{userName} finished task {task}.' => '{userName} کار  {task} را به پایان رساند.',
);
