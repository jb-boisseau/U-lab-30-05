<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Utwórz</strong> zadanie',
  '<strong>Edit</strong> task' => '<strong>Edytuj</strong> zadanie',
  'Assign users' => 'Przypisz użytkowników',
  'Cancel' => 'Anuluj',
  'Deadline' => 'Termin końcowy',
  'Save' => 'Zapisz',
  'What is to do?' => 'Co jest do zrobienia?',
);
