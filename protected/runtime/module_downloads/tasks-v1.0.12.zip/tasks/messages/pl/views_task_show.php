<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Potwierdź</strong> usunięcie',
  'Add Task' => 'Dodaj Zadanie',
  'Cancel' => 'Anuluj',
  'Delete' => 'Usuń',
  'Do you really want to delete this task?' => 'Na pewno usunąć to zadanie?',
  'No open tasks...' => 'Brak otwartych zadań...',
  'completed tasks' => 'wykonane zadania',
);
