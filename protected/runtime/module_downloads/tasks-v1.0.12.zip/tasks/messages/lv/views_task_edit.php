<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Atcelt',
  'Deadline' => '',
  'Save' => 'Saglabāt',
  'What is to do?' => '',
);
