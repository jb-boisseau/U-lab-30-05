<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Crear</strong> nueva tarea',
  '<strong>Edit</strong> task' => '<strong>Editar</strong> tarea',
  'Assign users' => 'Asignar usuarios',
  'Cancel' => 'Cancelar',
  'Deadline' => 'Fecha límite',
  'Save' => 'Grabar',
  'What is to do?' => '¿Qué hay que hacer?',
);
