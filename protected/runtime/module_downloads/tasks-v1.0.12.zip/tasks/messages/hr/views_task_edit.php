<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'poništi',
  'Deadline' => '',
  'Save' => 'Spremi',
  'What is to do?' => '',
);
