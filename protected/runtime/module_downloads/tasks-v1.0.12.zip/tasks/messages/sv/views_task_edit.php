<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Avbryt',
  'Deadline' => '',
  'Save' => 'Spara',
  'What is to do?' => '',
);
