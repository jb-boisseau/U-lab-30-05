<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Neue Aufgabe</strong> erstellen',
  '<strong>Edit</strong> task' => '<strong>Aufgabe</strong> bearbeiten',
  'Assign users' => 'Zugewiesene Benutzer',
  'Cancel' => 'Abbrechen',
  'Deadline' => 'Frist',
  'Save' => 'Speichern',
  'What is to do?' => 'Was ist zu tun?',
);
