<?php
return array (
  '{userName} finished task {task}.' => '{userName} завершил задачу {task}.',
);
