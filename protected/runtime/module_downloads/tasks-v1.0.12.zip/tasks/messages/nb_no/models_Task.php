<?php
return array (
  'Task' => 'Oppgave',
);
