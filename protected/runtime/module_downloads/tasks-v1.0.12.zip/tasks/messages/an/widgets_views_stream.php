<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Created by me' => '',
  'Creation time' => '',
  'Filter' => '',
  'Last update' => '',
  'Nobody assigned' => '',
  'Sorting' => '',
  'State is finished' => '',
  'State is open' => '',
  'Back to stream' => '@@@@',
  'No tasks found which matches your current filter(s)!' => '@@@@',
);
