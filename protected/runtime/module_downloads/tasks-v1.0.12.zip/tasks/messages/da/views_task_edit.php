<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Opret</strong> ny opgave',
  '<strong>Edit</strong> task' => '<strong>Rediger</strong> opgave',
  'Assign users' => 'Tildel bruger(e)',
  'Cancel' => 'Afbryd',
  'Deadline' => 'Deadline',
  'Save' => 'Gem',
  'What is to do?' => 'Hvad skal laves?',
);
