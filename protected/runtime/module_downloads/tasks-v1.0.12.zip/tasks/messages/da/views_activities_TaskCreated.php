<?php
return array (
  '{userName} created task {task}.' => '{userName} oprettede opgaven {task}.',
);
