<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Il n\'y a pas encore de tâche !</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Il n\'y a pas encore de tâche !</b><br>Soyez le premier à en créer une...',
  'Assigned to me' => 'Me l\'affecter',
  'Back to stream' => 'Retour au flux',
  'Created by me' => 'Créées par moi',
  'Creation time' => 'Date de création',
  'Filter' => 'Filtre',
  'Last update' => 'Dernière mise à jour',
  'No tasks found which matches your current filter(s)!' => 'Aucune tâche trouvée avec ces critères',
  'Nobody assigned' => 'Personne n\'est affecté',
  'Sorting' => 'Trier',
  'State is finished' => 'État est terminé',
  'State is open' => 'État est ouvert',
);
