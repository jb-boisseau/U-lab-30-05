<?php
return array (
  'Assigned user(s)' => 'Utilisateur(s) affecté(s)',
  'Deadline' => 'Date limite',
  'Tasks' => 'Tâches',
  'Title' => 'Titre',
);
