<?php
return array (
  '<strong>My</strong> tasks' => '',
  'From space: ' => '',
);
