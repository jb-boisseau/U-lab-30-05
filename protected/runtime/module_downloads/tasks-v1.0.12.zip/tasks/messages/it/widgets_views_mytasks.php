<?php
return array (
  '<strong>My</strong> tasks' => 'Le <strong>Mie</strong> attività',
  'From space: ' => 'Dallo space:',
);
