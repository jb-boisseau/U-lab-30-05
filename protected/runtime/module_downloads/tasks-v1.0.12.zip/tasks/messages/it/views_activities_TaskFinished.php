<?php
return array (
  '{userName} finished task {task}.' => '{userName} ha completato l\'attività {task}.',
);
