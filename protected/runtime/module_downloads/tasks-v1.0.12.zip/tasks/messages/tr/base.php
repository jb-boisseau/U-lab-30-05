<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => 'Son tarih',
  'Tasks' => 'Görevler',
  'Title' => 'Başlık',
);
