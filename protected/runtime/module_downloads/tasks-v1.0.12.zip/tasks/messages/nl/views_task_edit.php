<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Maak</strong> nieuwe taak',
  '<strong>Edit</strong> task' => '<strong>Bewerk</strong> taak',
  'Assign users' => 'Gebruikers koppelen',
  'Cancel' => 'Annuleren',
  'Deadline' => 'Deadline',
  'Save' => 'Opslaan',
  'What is to do?' => 'Wat moet er gedaan worden?',
);
