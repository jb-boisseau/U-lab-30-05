<?php
return array (
  'Assigned user(s)' => 'Gekoppelde gebruiker(s)',
  'Deadline' => 'Deadline',
  'Tasks' => 'Taken',
  'Title' => 'Titel',
);
