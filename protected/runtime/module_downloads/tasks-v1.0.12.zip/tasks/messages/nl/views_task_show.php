<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Bevestig</strong> verwijderen taak',
  'Add Task' => 'Taak toevoegen',
  'Cancel' => 'Annuleren',
  'Delete' => 'Verwijder',
  'Do you really want to delete this task?' => 'Wil je deze taak echt verwijderen?',
  'No open tasks...' => 'Geen open taken...',
  'completed tasks' => 'voltooide taken',
);
