<?php
return array (
  'Could not access task!' => 'Kon taak niet bereiken!',
);
