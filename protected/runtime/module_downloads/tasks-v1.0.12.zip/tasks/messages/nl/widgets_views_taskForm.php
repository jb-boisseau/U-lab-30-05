<?php
return array (
  'Assign users to this task' => 'Koppel gebruikers aan deze taak',
  'Deadline for this task?' => 'Deadline voor de taak?',
  'Preassign user(s) for this task.' => 'Preassign user(s) for this task.',
  'What to do?' => 'Wat is er te doen?',
);
