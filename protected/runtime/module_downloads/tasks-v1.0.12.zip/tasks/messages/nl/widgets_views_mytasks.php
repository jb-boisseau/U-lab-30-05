<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mijn</strong> taken',
  'From space: ' => 'Van space:',
);
