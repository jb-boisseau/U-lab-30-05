<?php
return array (
  'Description' => 'Opis',
  'Parent Folder ID' => 'ID roditeljske mape',
  'Title' => 'Naziv',
);
