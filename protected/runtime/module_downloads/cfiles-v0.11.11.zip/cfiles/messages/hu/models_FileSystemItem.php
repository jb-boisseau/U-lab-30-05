<?php
return array (
  'Is Public' => 'Nyilvános',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Figyelem: a mappa nyilvánossága érvényes a benne lévő fájlokra és mappákra is.',
);
