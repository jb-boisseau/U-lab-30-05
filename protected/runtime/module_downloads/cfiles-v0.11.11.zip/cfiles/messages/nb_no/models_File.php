<?php
return array (
  'Folder ID' => 'Mappe ID',
);
