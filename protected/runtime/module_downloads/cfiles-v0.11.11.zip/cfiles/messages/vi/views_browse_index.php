<?php
return array (
  'Could not save file %title%. ' => 'Không thể lưu file %title%.',
);
