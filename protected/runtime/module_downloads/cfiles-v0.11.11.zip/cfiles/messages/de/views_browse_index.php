<?php
return array (
  'Could not save file %title%. ' => 'Die Datei %title% konnte nicht gespeichert werden.',
);
