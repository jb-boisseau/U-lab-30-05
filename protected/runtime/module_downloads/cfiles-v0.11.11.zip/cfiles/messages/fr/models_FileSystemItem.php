<?php
return array (
  'Is Public' => 'Est public',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Note : Modifie la visibilité des dossiers, qui va être héritée par tous les fichiers et dossiers qu\'ils contiennent.',
);
