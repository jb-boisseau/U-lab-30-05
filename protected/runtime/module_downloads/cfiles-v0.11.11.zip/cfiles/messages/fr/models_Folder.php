<?php
return array (
  'Description' => 'Description',
  'Parent Folder ID' => 'ID dossier parent',
  'Title' => 'Titre',
);
