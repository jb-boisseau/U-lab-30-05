## Description

Adds a link list to spaces or user profiles.

### Features

- Add links and communicate about with other users
- Organize links in categories

__Author:__ Sebastian Stumpf
__Author website:__ [www.zeros.ones.de](http://www.zeros.ones.de)




