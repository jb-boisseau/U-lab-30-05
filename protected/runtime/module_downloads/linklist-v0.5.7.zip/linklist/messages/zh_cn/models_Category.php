<?php
return array (
  'Description' => '描述',
  'Sort Order' => '',
  'Title' => '标题',
);
