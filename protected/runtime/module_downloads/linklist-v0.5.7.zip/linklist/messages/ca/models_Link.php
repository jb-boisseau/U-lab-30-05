<?php
return array (
  'Category' => '',
  'Description' => 'Descripció',
  'Sort Order' => 'Ordre de classificació',
  'Title' => 'Títol',
);
