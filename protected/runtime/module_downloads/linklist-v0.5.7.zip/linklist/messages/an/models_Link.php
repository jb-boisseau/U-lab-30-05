<?php
return array (
  'Category' => '',
  'Description' => '',
  'Sort Order' => '',
  'Title' => 'Titulek',
);
