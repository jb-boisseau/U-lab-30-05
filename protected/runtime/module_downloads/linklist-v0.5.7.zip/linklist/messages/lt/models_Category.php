<?php
return array (
  'Description' => 'Aprašymas',
  'Sort Order' => 'Rūšiavimo tvarka',
  'Title' => 'Pavadinimas',
);
