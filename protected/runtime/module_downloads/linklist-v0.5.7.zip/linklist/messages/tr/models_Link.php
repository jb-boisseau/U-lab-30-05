<?php
return array (
  'Category' => '',
  'Description' => 'Açıklama',
  'Sort Order' => 'Sıralama',
  'Title' => 'Başlık',
);
