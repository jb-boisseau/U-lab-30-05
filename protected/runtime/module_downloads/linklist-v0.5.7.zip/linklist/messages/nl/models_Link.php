<?php
return array (
  'Category' => 'Categorie',
  'Description' => 'Beschrijving',
  'Sort Order' => 'Sorteervolgorde',
  'Title' => 'Titel',
);
