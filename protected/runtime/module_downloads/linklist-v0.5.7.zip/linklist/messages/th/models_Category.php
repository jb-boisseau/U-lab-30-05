<?php
return array (
  'Description' => '',
  'Sort Order' => 'Ordem de classificação',
  'Title' => 'Título',
);
