<?php
return array (
  'Category' => '',
  'Description' => 'Miêu tả',
  'Sort Order' => '',
  'Title' => 'Tiêu đề',
);
