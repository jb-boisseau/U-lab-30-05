<?php
return array (
  'Description' => 'Miêu tả',
  'Sort Order' => '',
  'Title' => 'Tiêu đề',
);
