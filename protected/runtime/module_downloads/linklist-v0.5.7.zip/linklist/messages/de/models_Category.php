<?php

return [
    'Title' => 'Titel',
    'Description' => 'Beschreibung',
    'Sort Order' => 'Sortierungs Position',
];
