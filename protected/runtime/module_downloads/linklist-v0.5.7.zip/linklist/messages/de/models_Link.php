<?php

return [
	'Category' => 'Kategorie',
    'Title' => 'Titel',
    'Description' => 'Beschreibung',
    'Sort Order' => 'Sortierungs Position',
];
