<?php
return array (
  'Description' => 'Beskrivelse',
  'Sort Order' => 'Sorterings rekkefølge',
  'Title' => 'Tittel',
);
