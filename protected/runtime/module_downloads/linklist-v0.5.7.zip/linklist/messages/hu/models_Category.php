<?php
return array (
  'Description' => 'Leírás',
  'Sort Order' => '',
  'Title' => 'Naslov',
);
