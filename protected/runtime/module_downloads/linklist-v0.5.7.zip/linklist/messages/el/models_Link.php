<?php
return array (
  'Category' => '',
  'Description' => 'Περιγραφή',
  'Sort Order' => '',
  'Title' => 'Τίτλος',
);
