<?php
return array (
  'Description' => 'Descriere',
  'Sort Order' => '',
  'Title' => 'Titlul',
);
