<?php
return array (
  'Category' => '',
  'Description' => 'Descriere',
  'Sort Order' => '',
  'Title' => 'Titlul',
);
