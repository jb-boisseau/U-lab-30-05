<?php
return array (
  'Category' => '',
  'Description' => 'توضیحات',
  'Sort Order' => 'ترتیب مرتب‌سازی',
  'Title' => 'عنوان',
);
