<?php
return array (
  'Category' => '',
  'Description' => 'Deskripsi',
  'Sort Order' => '',
  'Title' => 'Judul',
);
