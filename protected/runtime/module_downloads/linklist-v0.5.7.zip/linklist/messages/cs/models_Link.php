<?php
return array (
  'Category' => 'Kategorie',
  'Description' => 'Popis',
  'Sort Order' => 'Řazení',
  'Title' => 'Název',
);
