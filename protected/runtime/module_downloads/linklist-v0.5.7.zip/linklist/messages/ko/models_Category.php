<?php
return array (
  'Description' => '',
  'Sort Order' => '',
  'Title' => '제목',
);
