<?php
return array (
  'Category' => 'Categoria',
  'Description' => 'Descrizione',
  'Sort Order' => 'Ordinamento',
  'Title' => 'Titolo',
);
