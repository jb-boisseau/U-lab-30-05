Changelog
=========

1.0.4  (May 23, 2018)
-----------------------
- Enh: Added module screenshots

1.0.2  (May 15, 2018)
-----------------------
- Fix: Removed debug statement


1.0.1  (May 15, 2018)
-----------------------
- Fix: Event methods not method call


1.0.0  (May 15, 2018)
-----------------------
- Enh: Initial release

