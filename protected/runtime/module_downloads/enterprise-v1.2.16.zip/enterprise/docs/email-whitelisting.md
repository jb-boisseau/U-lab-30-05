E-Mail - Whitelisting
=====================

The email whitelist feature allows you to specify email rules for users who don't need to be approved after registration. 

You can define these rules at: `Administration` -> `Users` -> `Settings` -> `Whitelist`.

![E-Mail Whitelist](images/email-whitelist.png)