<button class="btn btn-info btn-sm" data-action-click="ui.modal.load" data-action-url="<?= $space->createUrl('/space/membership/invite') ?>">
    <i class="fa fa-plus"></i> <?= Yii::t('SpaceModule.widgets_views_inviteButton', 'Invite') ?>
</button>