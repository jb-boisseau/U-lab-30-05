<?php
return array (
  'Your are not a member of this space' => 'Você não é membro desse espaço',
);
