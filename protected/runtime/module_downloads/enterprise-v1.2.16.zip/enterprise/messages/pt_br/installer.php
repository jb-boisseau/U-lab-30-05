<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => '<strong>Licença</strong> Enterprise Edition',
  'Licence Serial Code' => 'Código Serial da Licença',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Especifique o seu código de licença Enterprise Edition abaixo, você também pode deixá-lo em branco para iniciar uma avaliação de 14 dias.',
);
