<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => '<strong>Licencia</strong> de Enterprise Edition',
  'Licence Serial Code' => 'Código de serie de la licencia',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Especifique su código de licencia de Enterprise Edition a continuación, también puede dejarlo en blanco para iniciar una prueba de 14 días.',
);
