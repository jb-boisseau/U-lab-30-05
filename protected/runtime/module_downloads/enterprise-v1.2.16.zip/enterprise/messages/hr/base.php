<?php
return array (
  'Hide sidebar' => 'Sakrij sidebar',
  'Show sidebar' => 'Prikaži sidebar',
);
