<?php
return array (
  'Your are not a member of this space' => 'Vi niste član ovog prostora',
);
