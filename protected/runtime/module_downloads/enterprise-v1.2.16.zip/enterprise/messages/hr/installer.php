<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Poduzetničko izdanje <strong>Licenca</strong>',
  'Licence Serial Code' => 'Serijski kod licence',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Navedite kôd licence za Poduzetničko izdanje, možete ga i ostaviti prazno kako biste započeli probni rok od 14 dana.',
);
