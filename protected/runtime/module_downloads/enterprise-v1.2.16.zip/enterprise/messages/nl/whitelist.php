<?php
return array (
  'A whitelist rule can either be in the form <strong>@example.com</strong> to allow each email of the given host or a complete address as <strong>user@example.com</strong>' => 'Een toegestane e-maillijsttregel kan ofwel in de vorm <strong>voorbeeld.com</ strong> zijn om elke e-mail van de gegeven domein of een volledig adres toe te staan als <strong>gebruiker@voorbeeld.com</ strong>',
  'Separate multiple rules by a new line.' => 'Scheid meerdere regels met een nieuwe regel.',
  'Separate multiple whitelist rules by a new line.' => 'Scheid meerdere toegestane e-mailregels met een nieuwe regel.',
);
