<?php
return array (
  'Enterprise Edition <strong>Licence</strong>' => 'Enterprise Edition <strong>Licentie</strong>',
  'Licence Serial Code' => 'Licentiecode',
  'Please specify your Enterprise Edition Licence Code below, you can also leave it blank to start a 14 days trial.' => 'Geef hieronder uw Enterprise Edition-licentiecode op, u kunt het veld ook leeg laten om 14 dagen uit te proberen..',
);
