<?php
return array (
  'Hide sidebar' => 'Verberg zijbalk',
  'Show sidebar' => 'Toon zijbalk',
);
