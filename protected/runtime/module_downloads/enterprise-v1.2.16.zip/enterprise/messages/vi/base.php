<?php
return array (
  'Hide sidebar' => 'Ẩn sidebar',
  'Show sidebar' => 'Hiện sidebar',
);
