<?php
return array (
  'Your are not a member of this space' => 'Du bist nicht Mitglied in diesem Space',
);
