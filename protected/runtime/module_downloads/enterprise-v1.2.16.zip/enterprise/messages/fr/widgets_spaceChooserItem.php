<?php
return array (
  'Your are not a member of this space' => 'Vous n\'êtes pas membre de cet espace',
);
