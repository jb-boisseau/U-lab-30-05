v0.9.8 04.10.2017
- Fix: #132 , #129 Added Conversation and Message Notification Categories