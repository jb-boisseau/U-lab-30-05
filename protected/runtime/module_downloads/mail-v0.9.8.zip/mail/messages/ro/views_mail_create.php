<?php
return array (
  'Add recipients' => '',
  'Close' => 'Închide',
  'New message' => '',
  'Send' => '',
);
