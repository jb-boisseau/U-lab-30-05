<?php
return array (
  'There are no messages yet.' => 'Non ci sono messaggi.',
);
