<?php
return array (
  '<strong>New</strong> message' => '<strong>Nová</strong> zpráva',
  'Reply now' => 'Odpovědět',
  'sent you a new message:' => 'vám posílá zprávu:',
);
