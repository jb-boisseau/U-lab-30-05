<?php
return array (
  'Conversations' => 'Konverzace',
  'New' => 'Nová',
  'New message' => 'Nová zpráva',
  'There are no messages yet.' => 'Zatím zde nejsou žádné zprávy.',
);
