<?php
return array (
  'Add more participants to your conversation...' => 'Adicionar mais participantes na sua conversa ...',
  'Close' => 'Fechar',
  'Send' => 'Enviar',
);
