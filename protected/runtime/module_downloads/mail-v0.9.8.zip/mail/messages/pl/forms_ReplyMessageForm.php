<?php
return array (
  'Message' => 'Wiadomość ',
);
