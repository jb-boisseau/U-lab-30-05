<?php
return array (
  'New message from {senderName}' => 'Новое сообщение от {senderName}',
  'and {counter} other users' => 'и {counter} других пользователей',
);
