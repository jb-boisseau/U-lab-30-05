<?php
return array (
  'There are no messages yet.' => 'No hay mensajes aún.',
);
