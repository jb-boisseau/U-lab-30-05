<?php
return array (
  'sent you a new message in' => 'vous a envoyé un nouveau message dans',
);
