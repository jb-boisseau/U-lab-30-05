<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '',
  '<strong>Confirm</strong> leaving conversation' => '',
  '<strong>Confirm</strong> message deletion' => '',
  'Add user' => '',
  'Cancel' => 'Atcelt',
  'Delete' => 'Dzēst',
  'Delete conversation' => '',
  'Do you really want to delete this conversation?' => '',
  'Do you really want to delete this message?' => '',
  'Do you really want to leave this conversation?' => '',
  'Leave' => '',
  'Leave conversation' => '',
  'Leave discussion' => '',
  'Send' => 'Sūtīt',
  'There are no messages yet.' => 'Šeit vēl nav nevienas ziņas.',
  'Write an answer...' => '',
);
