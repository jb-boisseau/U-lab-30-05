<?php
return array (
  'Add recipients' => 'اضافه كردن گيرنده',
  'Close' => 'بستن',
  'New message' => 'پیغام جدید',
  'Send' => 'ارسال',
);
