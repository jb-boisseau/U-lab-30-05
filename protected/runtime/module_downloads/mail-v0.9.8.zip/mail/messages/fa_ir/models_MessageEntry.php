<?php
return array (
  'New message in discussion from %displayName%' => 'پیغام جدید در بحث از %displayName%',
);
