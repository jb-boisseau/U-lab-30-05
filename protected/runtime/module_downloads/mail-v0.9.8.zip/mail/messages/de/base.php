<?php
return array (
  'Allow others to send you private messages' => 'Erlaube anderen Nutzern dir private Nachrichten zu senden',
  'Created At' => 'Erstellt am',
  'Created By' => 'Erstellt durch',
  'Is Originator' => 'Ist Ersteller',
  'Last Viewed' => 'Zuletzt betrachtet',
  'Message' => 'Nachricht',
  'Messages' => 'Nachrichten',
  'Receive private messages' => 'Private Nachrichten erhalten',
  'Title' => 'Betreff',
  'Updated At' => 'Zuletzt aktualisiert am',
  'Updated By' => 'Zuletzt aktualisiert durch',
  'User' => 'Benutzer',
);
