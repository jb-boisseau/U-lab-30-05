<?php
return array (
  'Conversations' => 'Beszélgetések',
  'New' => 'Új',
  'New message' => 'Új üzenet',
  'There are no messages yet.' => 'Még nincsenek üzenetek.',
);
