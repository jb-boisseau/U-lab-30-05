<?php
return array (
  'Edit message entry' => 'Rediger melding',
  'Save' => 'Lagre',
);
