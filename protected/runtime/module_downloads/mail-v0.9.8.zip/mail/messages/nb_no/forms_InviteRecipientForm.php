<?php
return array (
  'Recipient' => 'Mottaker',
  'You cannot send a email to yourself!' => 'Du kan ikke sende en e-mail til deg selv!',
);
