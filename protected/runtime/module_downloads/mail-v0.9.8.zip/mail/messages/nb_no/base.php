<?php
return array (
  'Allow others to send you private messages' => 'Tillat at andre kan sende deg private meldinger',
  'Created At' => 'Postet',
  'Created By' => 'Skrevet av',
  'Is Originator' => 'Er forfatter',
  'Last Viewed' => 'Sist sett',
  'Message' => 'Melding',
  'Messages' => 'Meldinger',
  'Receive private messages' => 'Motta private meldinger',
  'Title' => 'Tittel',
  'Updated At' => 'Oppdatert',
  'Updated By' => 'Oppdatert av',
  'User' => 'Bruker',
);
