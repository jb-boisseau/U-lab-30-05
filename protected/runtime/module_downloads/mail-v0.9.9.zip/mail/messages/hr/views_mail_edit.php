<?php
return array (
  'Edit message entry' => 'Uredi unos poruka',
  'Save' => 'Spremi',
);
