<?php
return array (
  'Conversations' => 'Razgovori',
  'New' => 'Novo',
  'New message' => 'Nova poruka',
  'There are no messages yet.' => 'Još nema poruka.',
);
