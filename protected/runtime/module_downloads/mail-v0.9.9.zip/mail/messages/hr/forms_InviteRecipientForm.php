<?php
return array (
  'Recipient' => 'Primatelj',
  'You cannot send a email to yourself!' => 'Ne možete poslati email sami sebi!',
);
