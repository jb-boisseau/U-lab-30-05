<?php
return array (
  'Add recipients' => 'Dodaj primatelje',
  'Close' => 'Zatvori',
  'New message' => 'Nova poruka',
  'Send' => 'Pošalji',
);
