<?php
return array (
  'Add more participants to your conversation...' => 'Dodajte još sudionika u vaš razgovor...',
  'Close' => 'Zatvori',
  'Send' => 'Pošalji',
);
