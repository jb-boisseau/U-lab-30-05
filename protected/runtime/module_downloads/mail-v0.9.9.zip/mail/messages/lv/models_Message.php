<?php
return array (
  'New message from {senderName}' => 'Jauna ziņa no {senderName}',
  'and {counter} other users' => 'un {counter} citiem lietotājiem',
);
