<?php
return array (
  'Recipient' => 'Saņēmējs',
  'You cannot send a email to yourself!' => 'Tu nevari nosūtīt ziņojumu sev pašam',
);
