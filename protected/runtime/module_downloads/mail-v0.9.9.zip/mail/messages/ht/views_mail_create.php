<?php
return array (
  'Add recipients' => '',
  'Close' => 'Fèmen',
  'New message' => '',
  'Send' => '',
);
