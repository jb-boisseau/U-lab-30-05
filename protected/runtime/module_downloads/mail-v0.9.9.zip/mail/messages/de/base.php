<?php
return array (
  'Allow others to send you private messages' => 'Erlaube anderen Nutzern, dir private Nachrichten zu senden',
  'Conversation' => 'Unterhaltung',
  'Created At' => 'Erstellt am',
  'Created By' => 'Erstellt durch',
  'Is Originator' => 'Ist Ersteller',
  'Last Viewed' => 'Zuletzt angesehen',
  'Message' => 'Nachricht',
  'Messages' => 'Nachrichten',
  'Receive Notifications when someone opens a new conversation.' => 'Benachrichtigungen erhalten, wenn jemand eine neue Unterhaltung eröffnet.',
  'Receive Notifications when someone sends you a message.' => 'Benachrichtigungen erhalten, wenn dir jemand eine Nachricht schickt.',
  'Receive private messages' => 'Private Nachrichten erhalten',
  'Title' => 'Betreff',
  'Updated At' => 'Aktualisiert am',
  'Updated By' => 'Aktualisiert durch',
  'User' => 'Benutzer',
);
