<?php
return array (
  'Add more participants to your conversation...' => 'Füge der Unterhaltung weitere Empfänger hinzu...',
  'Close' => 'Schließen',
  'Send' => 'Senden',
);
