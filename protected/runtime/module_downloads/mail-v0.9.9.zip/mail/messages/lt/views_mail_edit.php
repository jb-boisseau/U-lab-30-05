<?php
return array (
  'Edit message entry' => 'Redaguoti žinutės tekstą',
  'Save' => 'Išsaugoti',
);
