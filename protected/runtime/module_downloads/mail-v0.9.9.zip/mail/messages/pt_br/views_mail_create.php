<?php
return array (
  'Add recipients' => 'Adicionar destinatários',
  'Close' => 'Fechar',
  'New message' => 'Nova mensagem',
  'Send' => 'Enviar',
);
