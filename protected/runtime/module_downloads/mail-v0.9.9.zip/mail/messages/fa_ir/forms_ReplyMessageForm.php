<?php
return array (
  'Message' => 'پیغام',
);
