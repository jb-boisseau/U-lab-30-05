<?php
return array (
  'Add recipients' => '宛先を追加',
  'Close' => '閉じる',
  'New message' => '新しいメッセージ',
  'Send' => '送信',
);
