<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '',
  '<strong>Confirm</strong> leaving conversation' => '',
  '<strong>Confirm</strong> message deletion' => '',
  'Add user' => '',
  'Cancel' => 'Отказ',
  'Delete' => 'Изтрий',
  'Delete conversation' => '',
  'Do you really want to delete this conversation?' => '',
  'Do you really want to delete this message?' => '',
  'Do you really want to leave this conversation?' => '',
  'Leave' => '',
  'Leave conversation' => '',
  'Leave discussion' => '',
  'Send' => '',
  'There are no messages yet.' => '',
  'Write an answer...' => '',
);
