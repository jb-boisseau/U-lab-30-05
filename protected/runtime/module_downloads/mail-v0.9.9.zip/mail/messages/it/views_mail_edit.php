<?php
return array (
  'Edit message entry' => 'Modifica messaggio',
  'Save' => 'Salva',
);
