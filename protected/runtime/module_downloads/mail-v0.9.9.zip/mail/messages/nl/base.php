<?php
return array (
  'Allow others to send you private messages' => 'Sta anderen toe om u privéberichten te sturen',
  'Conversation' => 'Gesprek',
  'Created At' => 'Gemaakt op',
  'Created By' => 'Gemaakt door',
  'Is Originator' => 'Is bedenker',
  'Last Viewed' => 'Laatst weergegeven',
  'Message' => 'Bericht',
  'Messages' => 'Berichten',
  'Receive Notifications when someone opens a new conversation.' => 'Meldingen ontvangen wanneer iemand een nieuw gesprek opent.',
  'Receive Notifications when someone sends you a message.' => 'Ontvang meldingen wanneer iemand u een bericht stuurt.',
  'Receive private messages' => 'Ontvang privéberichten',
  'Title' => 'Titel',
  'Updated At' => 'Bijgewerkt op',
  'Updated By' => 'Bijgewerkt door',
  'User' => 'Gebruiker',
);
