<?php
return array (
  'Add more participants to your conversation...' => 'Adj hozzá további címzetteket...',
  'Close' => 'Bezár',
  'Send' => 'Küld',
);
