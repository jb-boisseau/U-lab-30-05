<?php
return array (
  'Add recipients' => 'Címzettek',
  'Close' => 'Bezár',
  'New message' => 'Új üzenet',
  'Send' => 'Elküldés',
);
