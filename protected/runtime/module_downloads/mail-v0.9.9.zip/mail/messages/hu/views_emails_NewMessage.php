<?php
return array (
  '<strong>New</strong> message' => '<strong>Új</strong> üzenet',
  'Reply now' => 'Válasz',
  'sent you a new message:' => 'üzenetet küldött:',
);
