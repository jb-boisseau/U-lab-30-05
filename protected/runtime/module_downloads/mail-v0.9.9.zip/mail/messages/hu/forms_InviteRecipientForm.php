<?php
return array (
  'Recipient' => 'Címzett',
  'You cannot send a email to yourself!' => 'Magadnak nem küldhetsz üzenetet!',
);
