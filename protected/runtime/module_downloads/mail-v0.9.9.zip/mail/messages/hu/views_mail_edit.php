<?php
return array (
  'Edit message entry' => 'Üzenet szerkesztése',
  'Save' => 'Mentés',
);
