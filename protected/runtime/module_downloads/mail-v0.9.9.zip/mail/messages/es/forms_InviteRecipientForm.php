<?php
return array (
  'Recipient' => 'Receptor',
  'You cannot send a email to yourself!' => 'No te puedes enviar mensajes tu mismo!',
);
