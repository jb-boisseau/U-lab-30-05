<?php
return array (
  'Add recipients' => 'Agregar destinatarios',
  'Close' => 'Cerrar',
  'New message' => 'Nuevo mensaje',
  'Send' => 'Enviar',
);
