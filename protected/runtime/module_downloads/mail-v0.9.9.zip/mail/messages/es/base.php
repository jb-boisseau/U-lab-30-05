<?php
return array (
  'Allow others to send you private messages' => 'Permitir que otros le envíen mensajes privados',
  'Conversation' => 'Conversación',
  'Created At' => 'Creado en',
  'Created By' => 'Creado por',
  'Is Originator' => 'Es Originario',
  'Last Viewed' => 'Visto por última vez',
  'Message' => 'Mensaje',
  'Messages' => 'Mensajes',
  'Receive Notifications when someone opens a new conversation.' => 'Recibir notificaciones cuando alguien abre una nueva conversación.',
  'Receive Notifications when someone sends you a message.' => 'Recibir notificaciones cuando alguien te envía un mensaje.',
  'Receive private messages' => 'Recibir mensajes privados',
  'Title' => 'Titulo',
  'Updated At' => 'Actualizado en',
  'Updated By' => 'Actualizado por',
  'User' => 'Usuario',
);
