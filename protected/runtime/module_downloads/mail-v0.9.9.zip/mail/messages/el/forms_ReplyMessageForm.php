<?php
return array (
  'Message' => 'Μήνυμα',
);
