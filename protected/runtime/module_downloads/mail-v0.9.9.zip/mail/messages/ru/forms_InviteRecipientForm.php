<?php
return array (
  'Recipient' => 'Получатель',
  'You cannot send a email to yourself!' => 'Вы не можете отправить сообщение самому себе!',
);
