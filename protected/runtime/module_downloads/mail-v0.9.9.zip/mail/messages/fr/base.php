<?php
return array (
  'Allow others to send you private messages' => 'Autoriser les autres utilisateurs à vous envoyer des messages privés',
  'Conversation' => 'Conversation',
  'Created At' => 'Créé le',
  'Created By' => 'Créé par',
  'Is Originator' => 'Est à l\'origine',
  'Last Viewed' => 'Dernière lecture',
  'Message' => 'Message',
  'Messages' => 'Messages',
  'Receive Notifications when someone opens a new conversation.' => 'Recevoir une notification lorsqu\'on crée une conversation.',
  'Receive Notifications when someone sends you a message.' => 'Recevoir une notification lorsqu\'on m\'envoie un message.',
  'Receive private messages' => 'Recevoir des messages privés',
  'Title' => 'Titre',
  'Updated At' => 'Mis à jour le',
  'Updated By' => 'Mis à jour par',
  'User' => 'Utilisateur',
);
