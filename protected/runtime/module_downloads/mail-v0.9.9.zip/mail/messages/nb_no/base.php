<?php
return array (
  'Allow others to send you private messages' => 'Tillat at andre kan sende deg private meldinger',
  'Conversation' => 'Samtale',
  'Created At' => 'Postet',
  'Created By' => 'Skrevet av',
  'Is Originator' => 'Er forfatter',
  'Last Viewed' => 'Sist sett',
  'Message' => 'Melding',
  'Messages' => 'Meldinger',
  'Receive Notifications when someone opens a new conversation.' => 'Motta varsel når noen starter en ny samtale.',
  'Receive Notifications when someone sends you a message.' => 'Motta varsel når noen sender deg en melding.',
  'Receive private messages' => 'Motta private meldinger',
  'Title' => 'Tittel',
  'Updated At' => 'Oppdatert',
  'Updated By' => 'Oppdatert av',
  'User' => 'Bruker',
);
