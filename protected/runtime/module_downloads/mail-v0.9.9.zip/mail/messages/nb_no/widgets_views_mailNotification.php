<?php
return array (
  'Messages' => 'Meldinger',
  'New message' => 'Ny melding',
  'Show all messages' => 'Vis alle meldinger',
);
