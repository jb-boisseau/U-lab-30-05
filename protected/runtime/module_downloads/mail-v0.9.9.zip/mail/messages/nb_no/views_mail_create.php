<?php
return array (
  'Add recipients' => 'Legg til mottakere',
  'Close' => 'Lukk',
  'New message' => 'Ny melding',
  'Send' => 'Send',
);
