0.9.9  (May 16, 2018)
----------------------
- Enh: Added global `StartConversation` permission

0.9.8 04.10.2017
----------------------
- Fix: #132 , #129 Added Conversation and Message Notification Categories