<?php
return array (
  ':count attending' => ':count deltar',
  ':count declined' => ':count deltar ikke',
  ':count maybe' => ':count deltar kanskje',
  'Participants:' => 'Deltagere:',
);
