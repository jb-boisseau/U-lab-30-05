<?php
return array (
  'Calendar' => 'Kalender',
  'Receive Calendar related Notifications.' => 'Bli varslet om hendelser knyttet til kalenderen',
);
