<?php
return array (
  ':count attending' => ':count deltager',
  ':count declined' => ':count afslået',
  ':count maybe' => ':count måske',
  'Participants:' => 'Deltagere:',
);
