<?php
return array (
  ':count attending' => ':count Zusagen',
  ':count declined' => ':count Absagen',
  ':count maybe' => ':count Vielleicht',
  'Participants:' => 'Teilnehmer:',
);
