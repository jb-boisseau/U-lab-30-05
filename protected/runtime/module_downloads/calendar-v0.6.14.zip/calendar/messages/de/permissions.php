<?php
return array (
  'Allows the user to create new calendar entries' => 'Erlaube Nutzern Kalendereinträge zu erstellen',
  'Allows the user to edit/delete existing calendar entries' => 'Erlaube Nutzern bestehende Kalendereinträge zu bearbeiten/löschen.',
  'Create entry' => 'Erstelle Kalendereinträge',
  'Manage entries' => 'Verwalte Kalendereinträge',
);
