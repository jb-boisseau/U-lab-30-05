<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% részt vesz a(z) %contentTitle% (-n).',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% talán részt vesz a(z) %contentTitle% (-n).',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nem vesz részt a(z) %contentTitle% (-n).',
);
