<?php
return array (
  '<strong>Create</strong> event' => '<strong>Esemény</strong> létrehozása',
  '<strong>Edit</strong> event' => '<strong>Esemény</strong> szerkesztése',
  'Basic' => 'Alap',
  'Everybody can participate' => 'Bárki részt vehet',
  'Files' => 'Fájlok',
  'No participants' => 'Nincsenek részt vevők',
  'Participation' => 'Részvétel',
  'Select event type...' => 'Válassz esemény típust...',
  'Title' => 'Tárgy',
);
