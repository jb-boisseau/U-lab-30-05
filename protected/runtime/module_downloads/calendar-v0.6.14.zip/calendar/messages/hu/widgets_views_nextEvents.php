<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Következő</strong> események',
  'Open Calendar' => 'Naptár megnyitása',
);
