<?php
return array (
  'Attend' => 'Részt vesz',
  'Decline' => 'Nem vesz részt',
  'Maybe' => 'Talán',
  'Participant information:' => 'Részt vevői információk:',
  'Read full description...' => 'Teljes leírás olvasása...',
  'Read full participation info...' => 'Teljes résztvevői leírás olvasása...',
);
