<?php
return array (
  'Attend' => 'Deelnemen',
  'Decline' => 'Afwijzen',
  'Maybe' => 'Misschien',
  'Participant information:' => 'Deelnemer informatie:',
  'Read full description...' => 'Lees de volledige beschrijving ...',
  'Read full participation info...' => 'Lees volledige deelname informatie ...',
);
