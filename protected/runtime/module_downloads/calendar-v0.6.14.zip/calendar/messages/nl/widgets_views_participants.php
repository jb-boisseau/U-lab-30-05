<?php
return array (
  ':count attending' => ':count geaccepteerd',
  ':count declined' => ':count afgewezen',
  ':count maybe' => ':count misschien',
  'Participants:' => 'Deelnemers:',
);
