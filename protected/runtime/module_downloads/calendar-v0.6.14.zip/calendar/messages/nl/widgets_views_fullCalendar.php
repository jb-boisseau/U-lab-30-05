<?php
return array (
  'Loading...' => 'Laden...',
);
