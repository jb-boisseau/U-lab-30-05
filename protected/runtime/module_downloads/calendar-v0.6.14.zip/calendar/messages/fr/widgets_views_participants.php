<?php
return array (
  ':count attending' => ':count oui',
  ':count declined' => ':count non',
  ':count maybe' => ':count peut-être',
  'Participants:' => 'Participants :',
);
