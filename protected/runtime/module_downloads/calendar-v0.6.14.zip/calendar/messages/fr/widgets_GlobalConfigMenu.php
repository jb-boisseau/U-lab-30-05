<?php
return array (
  'Defaults' => 'Général',
  'Event Types' => 'Types',
  'Other Calendars' => 'Autres calendriers',
  'Snippet' => 'Extrait',
);
