<?php
return array (
  ':count attending' => ':count dalyvaujančiu',
  ':count declined' => ':count atsisakiusiu dalyvauti',
  ':count maybe' => ':count galbūt dalyvausiančiu',
  'Participants:' => 'Dalyviai:',
);
