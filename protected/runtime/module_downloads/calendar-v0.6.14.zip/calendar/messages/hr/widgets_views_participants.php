<?php
return array (
  ':count attending' => ':broj prisustva',
  ':count declined' => ':broj odbijenica',
  ':count maybe' => ':broj možda',
  'Participants:' => 'Sudionici:',
);
