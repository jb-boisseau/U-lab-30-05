<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} otkazan događaj \'{contentTitle}\' u prostoru {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} otkazan događaj \'{contentTitle}\'',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} upravo ažurirani događaj {contentTitle} u prostoru {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} samo ažurirani događaj {contentTitle}.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} ponovno je otvorio događaj {contentTitle} u prostoru {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} ponovo je otvorio događaj {contentTitle}.',
);
