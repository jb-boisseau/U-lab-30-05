<?php
return array (
  'Attend' => 'Prisustvo',
  'Decline' => 'Odbij',
  'Maybe' => 'Možda',
  'Participant information:' => 'Informacije o sudioniku:',
  'Read full description...' => 'Pročitaj sve...',
  'Read full participation info...' => 'Pročitaj sve info o sudioniku...',
);
